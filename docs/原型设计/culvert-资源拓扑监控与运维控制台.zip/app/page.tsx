'use client';

import React, { useState, useEffect } from 'react';
import {
  INITIAL_RESOURCES,
  INITIAL_PORT_SEGMENTS,
  INITIAL_ACTIVITIES,
  ResourceItem,
  PortSegment,
  ActivityEvent,
} from '@/lib/mock-data';
import { TopologyDiagram } from '@/components/TopologyDiagram';
import { PortSpectrum } from '@/components/PortSpectrum';
import { CommandPalette } from '@/components/CommandPalette';
import { KioskMode } from '@/components/KioskMode';
import { ActivityStream } from '@/components/ActivityStream';
import { ResponsiveDegradedList } from '@/components/ResponsiveDegradedList';
import { ExposePortDrawer } from '@/components/ExposePortDrawer';
import { ResourceList } from '@/components/ResourceList';
import { ManagementView } from '@/components/ManagementView';
import {
  LayoutDashboard,
  ArrowRightLeft,
  Box,
  Server,
  Settings,
  Search,
  Monitor,
  Smartphone,
  Laptop,
  CheckCircle2,
  AlertTriangle,
  Zap,
  Activity,
  User,
  Plus,
} from 'lucide-react';

export default function OpsConsoleApp() {
  // Navigation & View States
  const [activeTab, setActiveTab] = useState<'overview' | 'forward' | 'container' | 'vm' | 'manage'>('overview');
  const [isKioskOpen, setIsKioskOpen] = useState(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [isExposeDrawerOpen, setIsExposeDrawerOpen] = useState(false);

  // Responsive mode simulator: 'auto' | 'desktop' | 'narrow'
  const [viewMode, setViewMode] = useState<'auto' | 'desktop' | 'narrow'>('auto');

  // Resource State with dynamic mock mutations
  const [resources, setResources] = useState<ResourceItem[]>(INITIAL_RESOURCES);
  const [portSegments, setPortSegments] = useState<PortSegment[]>(INITIAL_PORT_SEGMENTS);
  const [activities, setActivities] = useState<ActivityEvent[]>(INITIAL_ACTIVITIES);

  // Cross-component hover and highlight synchronization
  const [hoveredResourceId, setHoveredResourceId] = useState<string | null>(null);
  const [highlightedResourceId, setHighlightedResourceId] = useState<string | null>(null);

  // Global Keyboard shortcuts: ⌘K or Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Jump from Topology or Port Spectrum to corresponding list with highlight
  const handleSelectResource = (resource: ResourceItem) => {
    let targetTab: 'forward' | 'container' | 'vm' = 'forward';
    if (resource.type === 'container') targetTab = 'container';
    if (resource.type === 'vm') targetTab = 'vm';

    setActiveTab(targetTab);
    setHighlightedResourceId(resource.id);
  };

  const handleSelectResourceById = (resourceId: string) => {
    const found = resources.find((r) => r.id === resourceId);
    if (found) {
      handleSelectResource(found);
    }
  };

  // Add new Forward through Expose Port Drawer
  const handleAddResource = (newRes: ResourceItem) => {
    setResources((prev) => [newRes, ...prev]);

    // Update Port Spectrum
    const newPortSeg: PortSegment = {
      id: `p-${newRes.port}`,
      startPort: newRes.port,
      endPort: newRes.port,
      label: `${newRes.ingress} (${newRes.name})`,
      service: `${newRes.engine} → ${newRes.target}`,
      owner: newRes.owner,
      status: newRes.status,
      protocol: newRes.protocol,
      resourceId: newRes.id,
    };
    setPortSegments((prev) => [...prev, newPortSeg]);

    // Add to activity stream
    const newAct: ActivityEvent = {
      id: `act-${Date.now()}`,
      timestamp: new Date().toTimeString().split(' ')[0],
      title: '暴露端口成功',
      operator: newRes.owner,
      target: `${newRes.ingress} → ${newRes.target}`,
      level: 'info',
      details: `通过抽屉式表单暴露端口 :${newRes.port}，引擎 ${newRes.engine} 已挂载`,
      resourceId: newRes.id,
    };
    setActivities((prev) => [newAct, ...prev]);

    // Switch to tab & highlight
    setActiveTab('forward');
    setHighlightedResourceId(newRes.id);
  };

  // Filter anomalies command trigger
  const handleFilterAnomalies = () => {
    setActiveTab('forward');
    const firstDead = resources.find((r) => r.status === 'dead' || r.status === 'unknown');
    if (firstDead) {
      setHighlightedResourceId(firstDead.id);
    }
  };

  // Render Kiosk Mode if activated
  if (isKioskOpen) {
    return (
      <KioskMode
        resources={resources}
        activities={activities}
        onExitKiosk={() => setIsKioskOpen(false)}
      />
    );
  }

  // Determine whether to show desktop SVG or narrow list degradation
  const showDegradedView = viewMode === 'narrow';

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* 1. Main Navigation Header */}
      <header className="sticky top-0 z-40 bg-[#0e1422]/95 border-b border-[#1c283d] backdrop-blur-md px-4 sm:px-6 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          {/* Brand & Online Badge */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white font-mono font-bold text-xs shadow-md shadow-cyan-900/50">
                CL
              </div>
              <div className="flex items-baseline gap-2">
                <span className="font-bold text-sm sm:text-base tracking-wide text-slate-100">
                  运维控制台
                </span>
                <span className="text-[11px] font-mono text-cyan-400 font-medium">
                  Culvert
                </span>
              </div>
            </div>

            {/* Online Status Pill */}
            <div className="hidden sm:inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-950/60 border border-emerald-500/40 text-emerald-400 text-xs font-mono">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>在线</span>
            </div>
          </div>

          {/* Primary Navigation Tabs */}
          <nav className="flex items-center gap-1 bg-[#090e18] p-1 rounded-xl border border-[#1b273b] text-xs font-mono overflow-x-auto">
            <button
              id="tab-overview"
              onClick={() => setActiveTab('overview')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'overview'
                  ? 'bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#141d2d]'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>总览</span>
            </button>
            <button
              id="tab-forward"
              onClick={() => setActiveTab('forward')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'forward'
                  ? 'bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#141d2d]'
              }`}
            >
              <ArrowRightLeft className="w-3.5 h-3.5" />
              <span>转发</span>
            </button>
            <button
              id="tab-container"
              onClick={() => setActiveTab('container')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'container'
                  ? 'bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#141d2d]'
              }`}
            >
              <Box className="w-3.5 h-3.5" />
              <span>容器</span>
            </button>
            <button
              id="tab-vm"
              onClick={() => setActiveTab('vm')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'vm'
                  ? 'bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#141d2d]'
              }`}
            >
              <Server className="w-3.5 h-3.5" />
              <span>虚拟机</span>
            </button>
            <button
              id="tab-manage"
              onClick={() => setActiveTab('manage')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'manage'
                  ? 'bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#141d2d]'
              }`}
            >
              <Settings className="w-3.5 h-3.5" />
              <span>管理</span>
            </button>
          </nav>

          {/* Right Actions: Command Palette, Kiosk Mode, View Mode Simulator, User */}
          <div className="flex items-center gap-2">
            {/* Command Palette Trigger */}
            <button
              id="command-palette-trigger"
              onClick={() => setIsCommandPaletteOpen(true)}
              className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-[#121a29] border border-[#223149] hover:border-cyan-500/50 text-slate-300 hover:text-white transition-all text-xs font-mono cursor-pointer"
              title="按 ⌘K 或 Ctrl+K 打开命令面板"
            >
              <Search className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden md:inline text-slate-400">快捷命令</span>
              <kbd className="px-1.5 py-0.5 rounded bg-[#1b263b] text-[10px] text-cyan-300 border border-slate-700">
                ⌘K
              </kbd>
            </button>

            {/* Kiosk Mode Trigger Button */}
            <button
              id="open-kiosk-btn"
              onClick={() => setIsKioskOpen(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#141d2d] border border-[#24354e] hover:bg-[#1d2a40] text-purple-300 hover:text-purple-200 transition-colors text-xs font-mono cursor-pointer"
              title="切换到 Kiosk 监控大屏"
            >
              <Monitor className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">Kiosk 大屏</span>
            </button>

            {/* Responsive Fallback Switcher (Allows testing Desktop vs Narrow fallback) */}
            <div className="hidden sm:flex items-center rounded-lg bg-[#101725] p-0.5 border border-[#1e2c42] text-[11px] font-mono">
              <button
                onClick={() => setViewMode('desktop')}
                className={`p-1.5 rounded transition-colors cursor-pointer ${
                  viewMode === 'desktop'
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-700/50'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="桌面完整接线图 (≥1200px)"
              >
                <Laptop className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setViewMode('narrow')}
                className={`p-1.5 rounded transition-colors cursor-pointer ${
                  viewMode === 'narrow'
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-700/50'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="窄屏降级列表优先 (≤600px)"
              >
                <Smartphone className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Operator Badge */}
            <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-[#131b29] border border-[#202e44] text-xs font-mono text-slate-300">
              <User className="w-3.5 h-3.5 text-indigo-400" />
              <span className="font-semibold text-slate-200">admin</span>
            </div>
          </div>
        </div>
      </header>

      {/* 2. Main Page Body */}
      <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 py-6 flex-1 flex flex-col gap-6">
        {/* Tab 1: 总览 Dashboard */}
        {activeTab === 'overview' && (
          <>
            {/* Top Greeting & Quota Banner */}
            <section
              id="overview-header-banner"
              className="bg-[#101725] border border-[#1d2c42] rounded-xl p-5 shadow-lg flex flex-wrap items-center justify-between gap-4"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-cyan-600/30 to-blue-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300">
                  <Zap className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-xs font-mono text-slate-400 flex items-center gap-2">
                    <span>欢迎回来，</span>
                    <span className="font-semibold text-cyan-300">admin</span>
                  </div>
                  <h1 className="text-xl sm:text-2xl font-bold text-slate-100 mt-0.5">
                    资源拓扑监控与运维控制台
                  </h1>
                </div>
              </div>

              {/* Resource Quota Progress & KPI Pills */}
              <div className="flex flex-wrap items-center gap-4 sm:gap-6">
                {/* Quota Gauge */}
                <div className="flex items-center gap-3 bg-[#0b101c] px-4 py-2.5 rounded-xl border border-[#1b263b]">
                  <div className="relative w-11 h-11 flex items-center justify-center">
                    <svg className="w-11 h-11 -rotate-90" viewBox="0 0 36 36">
                      <path
                        className="text-slate-800"
                        strokeWidth="3.5"
                        stroke="currentColor"
                        fill="none"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      />
                      <path
                        className="text-cyan-400"
                        strokeDasharray="62, 100"
                        strokeWidth="3.5"
                        strokeLinecap="round"
                        stroke="currentColor"
                        fill="none"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      />
                    </svg>
                    <span className="absolute font-mono text-xs font-bold text-cyan-300">
                      62%
                    </span>
                  </div>
                  <div>
                    <div className="text-xs font-mono font-semibold text-slate-200">
                      资源总配额
                    </div>
                    <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                      端口已占 41 / 64
                    </div>
                  </div>
                </div>

                {/* KPI 1: 活跃转发 */}
                <div
                  onClick={() => setActiveTab('forward')}
                  className="px-4 py-2.5 rounded-xl bg-[#0b101c] border border-[#1b263b] hover:border-cyan-500/40 cursor-pointer transition-colors"
                >
                  <div className="text-xs font-mono text-slate-400">活跃转发</div>
                  <div className="flex items-baseline gap-2 mt-0.5">
                    <span className="text-2xl font-black font-mono text-cyan-300">
                      12
                    </span>
                    <span className="text-[10px] font-mono text-emerald-400">运行正常</span>
                  </div>
                </div>

                {/* KPI 2: 容器数量 */}
                <div
                  onClick={() => setActiveTab('container')}
                  className="px-4 py-2.5 rounded-xl bg-[#0b101c] border border-[#1b263b] hover:border-indigo-500/40 cursor-pointer transition-colors"
                >
                  <div className="text-xs font-mono text-slate-400">容器数量</div>
                  <div className="flex items-baseline gap-2 mt-0.5">
                    <span className="text-2xl font-black font-mono text-indigo-300">
                      08
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">资源统计</span>
                  </div>
                </div>

                {/* KPI 3: 异常关注 */}
                <div
                  onClick={() => handleFilterAnomalies()}
                  className="px-4 py-2.5 rounded-xl bg-[#181119] border border-rose-900/50 hover:border-rose-600/70 cursor-pointer transition-colors"
                >
                  <div className="text-xs font-mono text-rose-300">异常告警</div>
                  <div className="flex items-baseline gap-2 mt-0.5">
                    <span className="text-2xl font-black font-mono text-rose-400">
                      02
                    </span>
                    <span className="text-[10px] font-mono text-rose-300/80">需要关注</span>
                  </div>
                </div>
              </div>
            </section>

            {/* Primary Visual Zone: Topology Diagram vs Responsive Degraded List */}
            <section id="topology-section">
              {showDegradedView ? (
                <ResponsiveDegradedList
                  resources={resources}
                  onSelectResource={handleSelectResource}
                  onNavigateToTab={setActiveTab}
                />
              ) : (
                <div className="space-y-4">
                  <TopologyDiagram
                    resources={resources}
                    onSelectResource={handleSelectResource}
                    onNavigateToTab={setActiveTab}
                    hoveredResourceId={hoveredResourceId}
                    setHoveredResourceId={setHoveredResourceId}
                  />

                  {/* Built-in responsive mobile fallback auto-shows on small screens via CSS */}
                  <div className="sm:hidden">
                    <ResponsiveDegradedList
                      resources={resources}
                      onSelectResource={handleSelectResource}
                      onNavigateToTab={setActiveTab}
                    />
                  </div>
                </div>
              )}
            </section>

            {/* Secondary Visual: Port Spectrum (紧接接线图下方) */}
            <section id="port-spectrum-section">
              <PortSpectrum
                portSegments={portSegments}
                resources={resources}
                onSelectResourceById={handleSelectResourceById}
                hoveredResourceId={hoveredResourceId}
                setHoveredResourceId={setHoveredResourceId}
              />
            </section>

            {/* Activity Stream / Flight Recorder Section */}
            <section id="activity-stream-section">
              <ActivityStream
                activities={activities}
                onSelectResourceById={handleSelectResourceById}
              />
            </section>
          </>
        )}

        {/* Tab 2: 转发 (Forwards) */}
        {activeTab === 'forward' && (
          <ResourceList
            type="forward"
            title="端口转发规则"
            resources={resources}
            highlightedResourceId={highlightedResourceId}
            onOpenExposeDrawer={() => setIsExposeDrawerOpen(true)}
            onClearHighlight={() => setHighlightedResourceId(null)}
          />
        )}

        {/* Tab 3: 容器 (Containers) */}
        {activeTab === 'container' && (
          <ResourceList
            type="container"
            title="容器实例与反向代理"
            resources={resources}
            highlightedResourceId={highlightedResourceId}
            onOpenExposeDrawer={() => setIsExposeDrawerOpen(true)}
            onClearHighlight={() => setHighlightedResourceId(null)}
          />
        )}

        {/* Tab 4: 虚拟机 (VMs) */}
        {activeTab === 'vm' && (
          <ResourceList
            type="vm"
            title="轻量隔离微机 SmolVM"
            resources={resources}
            highlightedResourceId={highlightedResourceId}
            onOpenExposeDrawer={() => setIsExposeDrawerOpen(true)}
            onClearHighlight={() => setHighlightedResourceId(null)}
          />
        )}

        {/* Tab 5: 管理 (Management) */}
        {activeTab === 'manage' && <ManagementView />}
      </div>

      {/* 3. Global Drawers & Modals */}
      {/* ⌘K Command Palette */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        onOpenExposeDrawer={() => setIsExposeDrawerOpen(true)}
        onOpenContainerDrawer={() => setIsExposeDrawerOpen(true)}
        onNavigateTab={(tab) => setActiveTab(tab)}
        onEnterKiosk={() => setIsKioskOpen(true)}
        onFilterAnomalies={handleFilterAnomalies}
      />

      {/* Expose Port Drawer */}
      <ExposePortDrawer
        isOpen={isExposeDrawerOpen}
        onClose={() => setIsExposeDrawerOpen(false)}
        onAddResource={handleAddResource}
        existingResources={resources}
      />
    </div>
  );
}
