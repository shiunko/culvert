import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Culvert 资源拓扑监控与运维控制台',
  description: '基于接线图与端口频谱的资源拓扑可视化监控、告警流、⌘K命令面板与Kiosk大屏运维控制台原型',
  openGraph: {
    title: 'Culvert 资源拓扑监控与运维控制台',
    description: '基于接线图与端口频谱的资源拓扑可视化监控、告警流、⌘K命令面板与Kiosk大屏运维控制台原型',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Culvert 资源拓扑监控与运维控制台',
    description: '基于接线图与端口频谱的资源拓扑可视化监控、告警流、⌘K命令面板与Kiosk大屏运维控制台原型',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="zh-CN" className="dark">
      <body className="bg-[#0b0f17] text-slate-100 antialiased min-h-screen selection:bg-cyan-500/30 selection:text-cyan-200" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
