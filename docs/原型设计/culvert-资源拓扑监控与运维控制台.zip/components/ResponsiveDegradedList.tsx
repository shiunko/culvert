'use client';

import React from 'react';
import { ResourceItem, ResourceStatus } from '@/lib/mock-data';
import { ArrowRight, Smartphone, ExternalLink, AlertTriangle, CheckCircle2, XCircle } from 'lucide-react';

interface ResponsiveDegradedListProps {
  resources: ResourceItem[];
  onSelectResource: (resource: ResourceItem) => void;
  onNavigateToTab: (tab: 'overview' | 'forward' | 'container' | 'vm' | 'manage') => void;
}

export const ResponsiveDegradedList: React.FC<ResponsiveDegradedListProps> = ({
  resources,
  onSelectResource,
  onNavigateToTab,
}) => {
  const getStatusBadge = (status: ResourceStatus) => {
    switch (status) {
      case 'alive':
        return {
          bg: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
          label: '运行中',
          icon: <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />,
        };
      case 'dead':
        return {
          bg: 'bg-rose-500/15 text-rose-300 border-rose-500/30',
          label: '异常',
          icon: <XCircle className="w-3.5 h-3.5 text-rose-400" />,
        };
      case 'disabled':
        return {
          bg: 'bg-slate-800 text-slate-400 border-slate-700',
          label: '已禁用',
          icon: <span className="w-2 h-2 rounded-full bg-slate-500" />,
        };
      case 'unknown':
      default:
        return {
          bg: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
          label: '未知/告警',
          icon: <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />,
        };
    }
  };

  return (
    <div id="degraded-list-card" className="bg-[#121824] border border-[#1e2a3e] rounded-xl p-4 shadow-lg">
      {/* Banner indicating degradation */}
      <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-[#1b263b]">
        <div className="flex items-center gap-2 text-cyan-400">
          <Smartphone className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-semibold text-slate-100">
            接线图降级列表 (Narrow Screen Fallback)
          </h3>
        </div>
        <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-cyan-950/60 text-cyan-300 border border-cyan-800/60">
          列表优先视图
        </span>
      </div>

      <p className="text-xs text-slate-400 mb-3">
        当前为窄屏或降级展示模式，已隐藏 SVG 拓扑接线，保留完整的入口、引擎、目标及跳转能力。
      </p>

      {/* List Items */}
      <div className="space-y-2.5">
        {resources.slice(0, 6).map((item) => {
          const badge = getStatusBadge(item.status);

          return (
            <div
              key={item.id}
              id={`degraded-item-${item.id}`}
              onClick={() => onSelectResource(item)}
              className="p-3 rounded-lg bg-[#0f1624] border border-[#1a2538] hover:border-cyan-500/50 hover:bg-[#141e30] transition-all cursor-pointer flex flex-col gap-2"
            >
              {/* Header: Link Connection & Status */}
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 font-mono text-sm font-bold text-slate-100">
                  <span className="text-cyan-300">{item.ingress}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                  <span className="text-slate-200">{item.target}</span>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <span className={`text-[11px] font-mono px-2 py-0.5 rounded-full border flex items-center gap-1 ${badge.bg}`}>
                    {badge.icon}
                    <span>{badge.label}</span>
                  </span>
                </div>
              </div>

              {/* Sub info: Engine & Protocol & Resource Name */}
              <div className="flex items-center justify-between text-xs font-mono text-slate-400">
                <div className="flex items-center gap-2">
                  <span className="text-indigo-300 font-semibold">{item.engine}</span>
                  <span>·</span>
                  <span className="text-slate-300">{item.protocol}</span>
                  <span>·</span>
                  <span className="text-slate-400 truncate max-w-[140px]">{item.name}</span>
                </div>

                <div className="flex items-center gap-1 text-cyan-400 text-xs">
                  <span>定位</span>
                  <ExternalLink className="w-3 h-3" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-3 pt-3 border-t border-[#1b263b] flex items-center justify-between text-xs text-slate-400">
        <span>降级信息：资源名称、入口、引擎、目标、状态、跳转。</span>
        <button
          onClick={() => onNavigateToTab('forward')}
          className="text-cyan-400 hover:text-cyan-300 font-mono text-xs font-medium cursor-pointer"
        >
          查看全部资源 →
        </button>
      </div>
    </div>
  );
};
