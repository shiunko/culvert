'use client';

import React, { useState } from 'react';
import { ResourceItem, ResourceStatus } from '@/lib/mock-data';
import { ArrowRight, CheckCircle2, AlertTriangle, XCircle, Slash, ExternalLink, Activity } from 'lucide-react';

interface TopologyDiagramProps {
  resources: ResourceItem[];
  onSelectResource: (resource: ResourceItem) => void;
  onNavigateToTab: (tab: 'overview' | 'forward' | 'container' | 'vm' | 'manage') => void;
  hoveredResourceId?: string | null;
  setHoveredResourceId?: (id: string | null) => void;
}

export const TopologyDiagram: React.FC<TopologyDiagramProps> = ({
  resources,
  onSelectResource,
  onNavigateToTab,
  hoveredResourceId,
  setHoveredResourceId,
}) => {
  const [internalHoverId, setInternalHoverId] = useState<string | null>(null);
  const activeHoverId = hoveredResourceId !== undefined ? hoveredResourceId : internalHoverId;
  const setHover = setHoveredResourceId || setInternalHoverId;

  // We display the primary 5 rows in the topology diagram as instructed by the design document
  // "每条资源独立一行，避免连线交叉。超出数量时每类展示有限数量，其余以文字提示：还有 12 条转发，进入转发列表查看全部。"
  const displayResources = resources.slice(0, 5);
  const remainingForwardsCount = Math.max(0, resources.filter(r => r.type === 'forward').length - displayResources.filter(r => r.type === 'forward').length + 10);

  const getStatusColor = (status: ResourceStatus) => {
    switch (status) {
      case 'alive':
        return {
          stroke: '#55C98A',
          bg: 'bg-emerald-500/10',
          border: 'border-emerald-500/30',
          text: 'text-emerald-400',
          dot: '#55C98A',
          badge: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
          label: '运行中',
        };
      case 'dead':
        return {
          stroke: '#D95D5D',
          bg: 'bg-rose-500/10',
          border: 'border-rose-500/30',
          text: 'text-rose-400',
          dot: '#D95D5D',
          badge: 'bg-rose-500/15 text-rose-300 border-rose-500/30',
          label: '异常',
        };
      case 'disabled':
        return {
          stroke: '#64748B',
          bg: 'bg-slate-800/60',
          border: 'border-slate-700',
          text: 'text-slate-400',
          dot: '#64748B',
          badge: 'bg-slate-800 text-slate-400 border-slate-700',
          label: '已禁用',
        };
      case 'unknown':
      default:
        return {
          stroke: '#D9A441',
          bg: 'bg-amber-500/10',
          border: 'border-amber-500/30',
          text: 'text-amber-400',
          dot: '#D9A441',
          badge: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
          label: '未知/降级',
        };
    }
  };

  return (
    <div id="topology-card" className="bg-[#121824] border border-[#1e2a3e] rounded-xl p-5 shadow-lg relative overflow-hidden">
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-[#1b263b]">
        <div className="flex items-center gap-2.5">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <h2 className="text-base font-semibold text-slate-100 tracking-wide flex items-center gap-2">
            资源接线图
            <span className="text-xs font-mono font-normal text-slate-400 px-2 py-0.5 rounded bg-[#182234] border border-[#223249]">
              Topology View
            </span>
          </h2>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-4 text-xs font-mono text-slate-300">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#55C98A] shadow-[0_0_8px_#55C98A]" />
            <span className="text-slate-300">运行中 (Alive)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#D95D5D] shadow-[0_0_8px_#D95D5D]" />
            <span className="text-slate-300">异常 (Dead)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#D9A441]" />
            <span className="text-slate-300">未知/告警</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#64748B]" />
            <span className="text-slate-400">禁用</span>
          </div>
        </div>
      </div>

      {/* SVG & Wiring Structure Container */}
      <div className="relative">
        {/* Column Header Titles */}
        <div className="grid grid-cols-12 gap-2 text-xs font-mono uppercase tracking-wider text-slate-400 mb-3 px-3">
          <div className="col-span-3 flex items-center gap-1.5 text-cyan-400">
            <span className="w-1.5 h-1.5 bg-cyan-400 rounded-sm" />
            公网入口 (Ingress)
          </div>
          <div className="col-span-1 text-center text-slate-500">连接</div>
          <div className="col-span-4 text-center text-indigo-300 flex items-center justify-center gap-1.5">
            <span className="w-1.5 h-1.5 bg-indigo-400 rounded-sm" />
            服务引擎 (Engine)
          </div>
          <div className="col-span-1 text-center text-slate-500">连接</div>
          <div className="col-span-3 text-right text-emerald-300 flex items-center justify-end gap-1.5">
            <span className="w-1.5 h-1.5 bg-emerald-400 rounded-sm" />
            内网目标 (Target)
          </div>
        </div>

        {/* Rows of wiring */}
        <div className="space-y-3">
          {displayResources.map((item, index) => {
            const statusConfig = getStatusColor(item.status);
            const isHovered = activeHoverId === item.id;

            return (
              <div
                key={item.id}
                id={`topo-row-${item.id}`}
                onClick={() => onSelectResource(item)}
                onMouseEnter={() => setHover(item.id)}
                onMouseLeave={() => setHover(null)}
                className={`group relative grid grid-cols-12 items-center gap-2 px-3 py-3 rounded-lg border transition-all duration-200 cursor-pointer ${
                  isHovered
                    ? 'bg-[#182337] border-cyan-500/50 shadow-md shadow-cyan-950/40 translate-x-0.5'
                    : 'bg-[#101723]/90 border-[#1a2538] hover:border-[#2e4162] hover:bg-[#141d2d]'
                }`}
                title="点击跳转至该资源列表并高亮定位"
              >
                {/* Col 1: 公网入口 */}
                <div className="col-span-3 flex items-center gap-2 overflow-hidden">
                  <div className="flex flex-col">
                    <span className="font-mono text-sm font-medium text-slate-100 group-hover:text-cyan-300 transition-colors">
                      {item.ingress}
                    </span>
                    <span className="text-[11px] text-slate-400 truncate max-w-[130px]">
                      {item.name}
                    </span>
                  </div>
                </div>

                {/* Col 2: Connector 1 (SVG) */}
                <div className="col-span-1 flex items-center justify-center">
                  <svg className="w-full h-7 overflow-visible" viewBox="0 0 50 20" preserveAspectRatio="none">
                    <defs>
                      <marker
                        id={`arr1-${item.id}`}
                        markerWidth="5"
                        markerHeight="5"
                        refX="4"
                        refY="2.5"
                        orient="auto"
                      >
                        <polygon points="0 0, 5 2.5, 0 5" fill={statusConfig.stroke} />
                      </marker>
                    </defs>
                    <path
                      d="M 2 10 L 44 10"
                      stroke={statusConfig.stroke}
                      strokeWidth={isHovered ? '2.5' : '1.5'}
                      fill="none"
                      strokeDasharray={item.status === 'disabled' ? '4 3' : undefined}
                      className={item.status === 'alive' ? 'animate-flow-dash' : ''}
                      markerEnd={`url(#arr1-${item.id})`}
                      opacity={item.status === 'disabled' ? 0.4 : 0.9}
                    />
                  </svg>
                </div>

                {/* Col 3: 服务引擎 (Center Node) */}
                <div className="col-span-4 flex items-center justify-center">
                  <div
                    className={`w-full max-w-[190px] px-3 py-1.5 rounded-md border flex items-center justify-between gap-2 transition-all ${
                      item.status === 'alive'
                        ? 'bg-[#152336] border-[#294266] text-cyan-200'
                        : item.status === 'dead'
                        ? 'bg-rose-950/30 border-rose-800/60 text-rose-200'
                        : item.status === 'unknown'
                        ? 'bg-amber-950/30 border-amber-800/60 text-amber-200'
                        : 'bg-slate-800/40 border-slate-700 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{
                          backgroundColor: statusConfig.dot,
                          boxShadow: item.status === 'alive' ? `0 0 8px ${statusConfig.dot}` : 'none',
                        }}
                      />
                      <span className="font-mono text-xs font-semibold truncate tracking-tight">
                        {item.engine}
                      </span>
                    </div>

                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#0b0f17]/70 text-slate-300 shrink-0 border border-slate-700/50">
                      {item.protocol}
                    </span>
                  </div>
                </div>

                {/* Col 4: Connector 2 (SVG) */}
                <div className="col-span-1 flex items-center justify-center">
                  <svg className="w-full h-7 overflow-visible" viewBox="0 0 50 20" preserveAspectRatio="none">
                    <defs>
                      <marker
                        id={`arr2-${item.id}`}
                        markerWidth="5"
                        markerHeight="5"
                        refX="4"
                        refY="2.5"
                        orient="auto"
                      >
                        <polygon points="0 0, 5 2.5, 0 5" fill={statusConfig.stroke} />
                      </marker>
                    </defs>
                    <path
                      d="M 2 10 L 44 10"
                      stroke={statusConfig.stroke}
                      strokeWidth={isHovered ? '2.5' : '1.5'}
                      fill="none"
                      strokeDasharray={item.status === 'disabled' ? '4 3' : undefined}
                      className={item.status === 'alive' ? 'animate-flow-dash' : ''}
                      markerEnd={`url(#arr2-${item.id})`}
                      opacity={item.status === 'disabled' ? 0.4 : 0.9}
                    />
                  </svg>
                </div>

                {/* Col 5: 内网目标 */}
                <div className="col-span-3 flex items-center justify-end gap-2 text-right">
                  <div className="flex flex-col items-end">
                    <span className="font-mono text-xs font-semibold text-slate-200">
                      {item.target}
                    </span>
                    <span className="text-[11px] font-mono text-slate-400">
                      {item.latency}
                    </span>
                  </div>
                  <ExternalLink className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity shrink-0 ml-1" />
                </div>

                {/* Hover Quick Card Popup */}
                {isHovered && (
                  <div className="absolute left-1/2 -top-12 -translate-x-1/2 z-20 pointer-events-none bg-[#0a0e17] border border-cyan-500/40 text-xs px-3 py-1.5 rounded-lg shadow-xl shadow-black/80 flex items-center gap-3 whitespace-nowrap">
                    <span className="text-cyan-300 font-mono font-medium">{item.name}</span>
                    <span className="text-slate-400">|</span>
                    <span className="text-slate-300">延迟: <span className="font-mono text-emerald-400">{item.latency}</span></span>
                    <span className="text-slate-400">|</span>
                    <span className="text-slate-300">吞吐: <span className="font-mono text-indigo-300">{item.throughput}</span></span>
                    <span className="text-slate-400">|</span>
                    <span className={`px-1.5 py-0.2 rounded text-[10px] ${statusConfig.badge}`}>{statusConfig.label}</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Bottom notes & navigation link */}
        <div className="mt-4 pt-3 border-t border-[#1b263b] flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-slate-500" />
            <span>每条资源独立一行，避免连线交叉。点击整条连接可定位并跳转。</span>
          </div>

          <button
            id="view-all-forwards-btn"
            onClick={() => onNavigateToTab('forward')}
            className="inline-flex items-center gap-1.5 text-cyan-400 hover:text-cyan-300 hover:underline font-mono transition-colors font-medium cursor-pointer"
          >
            <span>还有 {remainingForwardsCount} 条转发，进入转发列表查看全部</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
