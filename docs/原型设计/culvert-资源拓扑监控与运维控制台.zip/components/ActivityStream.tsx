'use client';

import React, { useState } from 'react';
import { ActivityEvent, ActivityLevel } from '@/lib/mock-data';
import { Activity, Clock, AlertTriangle, AlertCircle, Info, Filter, ArrowRight } from 'lucide-react';

interface ActivityStreamProps {
  activities: ActivityEvent[];
  onSelectResourceById?: (resourceId: string) => void;
}

export const ActivityStream: React.FC<ActivityStreamProps> = ({
  activities,
  onSelectResourceById,
}) => {
  const [levelFilter, setLevelFilter] = useState<'ALL' | ActivityLevel>('ALL');

  const filteredActivities = activities.filter((act) => {
    if (levelFilter === 'ALL') return true;
    return act.level === levelFilter;
  });

  const getLevelBadge = (level: ActivityLevel) => {
    switch (level) {
      case 'error':
        return {
          icon: <AlertCircle className="w-3.5 h-3.5 text-rose-400" />,
          badge: 'bg-rose-500/15 text-rose-300 border-rose-500/30',
          dot: 'bg-rose-400',
          label: '错误',
        };
      case 'warning':
        return {
          icon: <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />,
          badge: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
          dot: 'bg-amber-400',
          label: '警告/自愈',
        };
      case 'info':
      default:
        return {
          icon: <Info className="w-3.5 h-3.5 text-cyan-400" />,
          badge: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30',
          dot: 'bg-cyan-400',
          label: '信息',
        };
    }
  };

  return (
    <div id="activity-stream-card" className="bg-[#121824] border border-[#1e2a3e] rounded-xl p-5 shadow-lg flex flex-col h-full">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-[#1b263b]">
        <div className="flex items-center gap-2.5">
          <Activity className="w-4 h-4 text-purple-400" />
          <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
            活动记录
            <span className="text-xs font-mono font-normal text-slate-400 px-2 py-0.5 rounded bg-[#182234] border border-[#223249]">
              飞行记录仪
            </span>
          </h3>
          <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-emerald-950/60 border border-emerald-700/50 text-emerald-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            实时
          </span>
        </div>

        {/* Level Filters */}
        <div className="flex items-center gap-1 text-xs font-mono bg-[#0e1420] p-0.5 rounded-lg border border-[#1f2b3e]">
          <button
            onClick={() => setLevelFilter('ALL')}
            className={`px-2 py-1 rounded transition-colors cursor-pointer ${
              levelFilter === 'ALL'
                ? 'bg-slate-700 text-slate-100 font-medium'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            全部
          </button>
          <button
            onClick={() => setLevelFilter('info')}
            className={`px-2 py-1 rounded transition-colors cursor-pointer ${
              levelFilter === 'info'
                ? 'bg-cyan-950/60 text-cyan-300 border border-cyan-700/50 font-medium'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            信息
          </button>
          <button
            onClick={() => setLevelFilter('warning')}
            className={`px-2 py-1 rounded transition-colors cursor-pointer ${
              levelFilter === 'warning'
                ? 'bg-amber-950/60 text-amber-300 border border-amber-700/50 font-medium'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            警告
          </button>
          <button
            onClick={() => setLevelFilter('error')}
            className={`px-2 py-1 rounded transition-colors cursor-pointer ${
              levelFilter === 'error'
                ? 'bg-rose-950/60 text-rose-300 border border-rose-700/50 font-medium'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            错误
          </button>
        </div>
      </div>

      {/* Events List */}
      <div className="space-y-3 flex-1 overflow-y-auto pr-1">
        {filteredActivities.map((act) => {
          const cfg = getLevelBadge(act.level);

          return (
            <div
              key={act.id}
              id={`activity-event-${act.id}`}
              className="p-3 rounded-lg bg-[#0e1522] border border-[#1a2538] hover:border-[#2b3c58] transition-colors relative"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${cfg.dot}`} />
                  <span className="text-xs font-semibold text-slate-100">
                    {act.title}
                  </span>
                  <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded border ${cfg.badge}`}>
                    {cfg.label}
                  </span>
                </div>
                <div className="flex items-center gap-1 text-[11px] font-mono text-slate-400">
                  <Clock className="w-3 h-3 text-slate-500" />
                  <span>{act.timestamp}</span>
                </div>
              </div>

              {/* Actor and Target */}
              <div className="mt-1.5 flex items-center gap-2 text-xs font-mono text-slate-300">
                <span className="text-indigo-400">{act.operator}</span>
                <span className="text-slate-600">·</span>
                <span
                  onClick={() => act.resourceId && onSelectResourceById && onSelectResourceById(act.resourceId)}
                  className={`text-slate-200 ${act.resourceId ? 'hover:text-cyan-300 cursor-pointer underline decoration-dotted' : ''}`}
                >
                  {act.target}
                </span>
              </div>

              {/* Event Description */}
              <p className="mt-1 text-xs text-slate-400 font-sans leading-relaxed">
                {act.details}
              </p>
            </div>
          );
        })}
      </div>

      {/* Footer explanation */}
      <div className="mt-3 pt-2 border-t border-[#1b263b] text-[11px] text-slate-400 font-mono">
        记录包含时间、操作者、资源、事件描述与严重程度。
      </div>
    </div>
  );
};
