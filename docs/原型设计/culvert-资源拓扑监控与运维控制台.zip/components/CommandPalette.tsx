'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Search, Command, ArrowRight, ShieldAlert, Plus, Server, Box, Monitor, Clock, FileText, CornerDownLeft, X } from 'lucide-react';

export interface CommandItem {
  id: string;
  category: '常用命令' | '页面跳转' | '运维诊断';
  title: string;
  description: string;
  icon: React.ReactNode;
  shortcut?: string;
  action: () => void;
}

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenExposeDrawer: () => void;
  onOpenContainerDrawer: () => void;
  onNavigateTab: (tab: 'overview' | 'forward' | 'container' | 'vm' | 'manage') => void;
  onEnterKiosk: () => void;
  onFilterAnomalies: () => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onOpenExposeDrawer,
  onOpenContainerDrawer,
  onNavigateTab,
  onEnterKiosk,
  onFilterAnomalies,
}) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const commands: CommandItem[] = [
    {
      id: 'cmd-expose-port',
      category: '常用命令',
      title: '暴露端口',
      description: '打开转发创建抽屉式表单，配置公网入口映射',
      icon: <Plus className="w-4 h-4 text-cyan-400" />,
      shortcut: 'P',
      action: () => {
        onClose();
        onOpenExposeDrawer();
      },
    },
    {
      id: 'cmd-create-container',
      category: '常用命令',
      title: '创建容器',
      description: '打开容器创建表单，调度到工作节点',
      icon: <Box className="w-4 h-4 text-indigo-400" />,
      shortcut: 'C',
      action: () => {
        onClose();
        onOpenContainerDrawer();
      },
    },
    {
      id: 'cmd-manage-alloc',
      category: '常用命令',
      title: '主机容器分配',
      description: '进入管理页面，查看宿主机负载与资源额度',
      icon: <Server className="w-4 h-4 text-emerald-400" />,
      shortcut: 'M',
      action: () => {
        onClose();
        onNavigateTab('manage');
      },
    },
    {
      id: 'cmd-nav-kiosk',
      category: '页面跳转',
      title: 'Kiosk 大屏监控',
      description: '开启沉浸式远距离 NOC 监控看板，包含时钟与异常流',
      icon: <Monitor className="w-4 h-4 text-purple-400" />,
      shortcut: 'K',
      action: () => {
        onClose();
        onEnterKiosk();
      },
    },
    {
      id: 'cmd-nav-overview',
      category: '页面跳转',
      title: '返回总览 Dashboard',
      description: '查看首屏接线图、端口频谱与运行指标',
      icon: <Command className="w-4 h-4 text-slate-400" />,
      action: () => {
        onClose();
        onNavigateTab('overview');
      },
    },
    {
      id: 'cmd-nav-forwards',
      category: '页面跳转',
      title: '端口转发列表',
      description: '查看并筛选所有活动与休眠的公网入口转发规则',
      icon: <ArrowRight className="w-4 h-4 text-cyan-400" />,
      action: () => {
        onClose();
        onNavigateTab('forward');
      },
    },
    {
      id: 'cmd-nav-containers',
      category: '页面跳转',
      title: '容器实例管理',
      description: '查看容器引擎生命周期、网卡桥接与日志输出',
      icon: <Box className="w-4 h-4 text-indigo-400" />,
      action: () => {
        onClose();
        onNavigateTab('container');
      },
    },
    {
      id: 'cmd-nav-vms',
      category: '页面跳转',
      title: '微虚拟机 SmolVM',
      description: '轻量隔离微机沙箱状态与 TAP 端口绑定',
      icon: <Server className="w-4 h-4 text-amber-400" />,
      action: () => {
        onClose();
        onNavigateTab('vm');
      },
    },
    {
      id: 'cmd-diag-anomalies',
      category: '运维诊断',
      title: '筛选异常资源 (Dead / Warning)',
      description: '仅高亮并查看当前故障连接与不可达端口',
      icon: <ShieldAlert className="w-4 h-4 text-rose-400" />,
      action: () => {
        onClose();
        onFilterAnomalies();
      },
    },
  ];

  const filteredCommands = commands.filter((cmd) => {
    if (!query.trim()) return true;
    const q = query.toLowerCase();
    return (
      cmd.title.toLowerCase().includes(q) ||
      cmd.description.toLowerCase().includes(q) ||
      cmd.category.toLowerCase().includes(q)
    );
  });

  // Focus input when modal opens
  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => {
        inputRef.current?.focus();
      }, 50);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  // Handle keyboard shortcuts inside palette
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev + 1) % Math.max(1, filteredCommands.length));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev - 1 + filteredCommands.length) % Math.max(1, filteredCommands.length));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (filteredCommands[selectedIndex]) {
          filteredCommands[selectedIndex].action();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, filteredCommands, selectedIndex, onClose]);

  if (!isOpen) return null;

  return (
    <div
      id="command-palette-backdrop"
      className="fixed inset-0 z-50 flex items-start justify-center pt-20 sm:pt-28 px-4 bg-black/75 backdrop-blur-sm transition-opacity"
      onClick={onClose}
    >
      <div
        id="command-palette-modal"
        className="w-full max-w-xl bg-[#0f1624] border border-[#23354f] rounded-xl shadow-2xl overflow-hidden flex flex-col transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Header */}
        <div className="flex items-center px-4 py-3.5 border-b border-[#1f2e46] gap-3 bg-[#131b2b]">
          <Search className="w-5 h-5 text-cyan-400 shrink-0" />
          <input
            ref={inputRef}
            id="command-palette-input"
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            placeholder="搜索命令，例如：暴露端口、创建容器、Kiosk..."
            className="flex-1 bg-transparent text-slate-100 placeholder-slate-400 text-sm focus:outline-none font-sans"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-slate-400 hover:text-slate-200 text-xs p-1"
            >
              清除
            </button>
          )}
          <button
            id="close-command-palette-btn"
            onClick={onClose}
            className="text-xs font-mono px-2 py-1 rounded bg-[#1c273a] text-slate-400 hover:text-slate-200 border border-slate-700/60"
          >
            Esc
          </button>
        </div>

        {/* Command List Body */}
        <div className="max-h-80 overflow-y-auto p-2 divide-y divide-[#182335]">
          {filteredCommands.length > 0 ? (
            <div className="space-y-1">
              {filteredCommands.map((cmd, idx) => {
                const isSelected = idx === selectedIndex;
                return (
                  <div
                    key={cmd.id}
                    id={`cmd-item-${cmd.id}`}
                    onMouseEnter={() => setSelectedIndex(idx)}
                    onClick={cmd.action}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-sm cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-cyan-950/40 border border-cyan-500/50 text-cyan-100'
                        : 'text-slate-300 hover:bg-[#151f30] border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`p-1.5 rounded-md ${isSelected ? 'bg-cyan-900/50' : 'bg-[#182337]'}`}>
                        {cmd.icon}
                      </div>
                      <div className="flex flex-col min-w-0">
                        <div className="flex items-center gap-2">
                          <span className={`font-medium ${isSelected ? 'text-cyan-200' : 'text-slate-200'}`}>
                            {cmd.title}
                          </span>
                          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#0b101b] text-slate-400 border border-slate-800">
                            {cmd.category}
                          </span>
                        </div>
                        <span className="text-xs text-slate-400 truncate">
                          {cmd.description}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0 ml-2">
                      {cmd.shortcut && (
                        <kbd className="hidden sm:inline-block font-mono text-[11px] px-1.5 py-0.5 rounded bg-[#182337] border border-slate-700 text-slate-400">
                          {cmd.shortcut}
                        </kbd>
                      )}
                      {isSelected && (
                        <span className="flex items-center text-cyan-400 text-xs font-mono">
                          <CornerDownLeft className="w-3.5 h-3.5" />
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-12 text-center text-slate-400">
              <Command className="w-8 h-8 mx-auto text-slate-600 mb-2 opacity-50" />
              <p className="text-sm font-medium text-slate-300">无匹配命令</p>
              <p className="text-xs text-slate-400 mt-1">请尝试输入 “暴露”、“容器”、“大屏” 或 “转发”</p>
            </div>
          )}
        </div>

        {/* Footer info bar */}
        <div className="px-4 py-2 bg-[#0c121d] border-t border-[#1a263a] flex items-center justify-between text-xs text-slate-400 font-mono">
          <div className="flex items-center gap-3">
            <span>↑↓ 切换选择</span>
            <span>·</span>
            <span>Enter 执行</span>
            <span>·</span>
            <span>Esc 关闭</span>
          </div>
          <span className="text-cyan-400">
            {filteredCommands.length} 个命令
          </span>
        </div>
      </div>
    </div>
  );
};
