'use client';

import React, { useState, useEffect } from 'react';
import { ResourceItem, ActivityEvent } from '@/lib/mock-data';
import { Monitor, AlertTriangle, ShieldCheck, Wifi, ArrowLeft, Clock, Activity, Zap, RefreshCw } from 'lucide-react';

interface KioskModeProps {
  resources: ResourceItem[];
  activities: ActivityEvent[];
  onExitKiosk: () => void;
}

export const KioskMode: React.FC<KioskModeProps> = ({
  resources,
  activities,
  onExitKiosk,
}) => {
  const [timeStr, setTimeStr] = useState<string>('14:32:08');
  const [dateStr, setDateStr] = useState<string>('2026年9月14日 星期一');
  const [pulseCount, setPulseCount] = useState(0);

  // Digital clock running in real time
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toTimeString().split(' ')[0]
      );
      setDateStr(
        now.toLocaleDateString('zh-CN', {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          weekday: 'long',
        })
      );
      setPulseCount((prev) => prev + 1);
    };

    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  const anomalyResources = resources.filter((r) => r.status === 'dead' || r.status === 'unknown');
  const aliveResources = resources.filter((r) => r.status === 'alive');
  const anomalyActivities = activities.filter((a) => a.level === 'error' || a.level === 'warning');

  return (
    <div
      id="kiosk-mode-container"
      className="min-h-screen bg-[#060a12] text-slate-100 flex flex-col p-4 sm:p-6 lg:p-8 font-sans selection:bg-cyan-500/30"
    >
      {/* Kiosk Top Header */}
      <header className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-[#1b263b]">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-4 h-4 rounded-full bg-cyan-400 shadow-[0_0_15px_#22d3ee] flex items-center justify-center">
              <span className="w-1.5 h-1.5 bg-[#060a12] rounded-full" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black tracking-widest font-mono text-cyan-400">
                CULVERT MONITOR
              </h1>
              <p className="text-xs font-mono text-slate-400 tracking-wider">
                NETWORK TOPOLOGY & STATUS OPS CENTER
              </p>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>实时数据流已连接 · 1000ms 刷新</span>
          </div>
        </div>

        {/* Right side: Digital Clock & Exit Button */}
        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="font-mono text-2xl sm:text-3xl font-black tracking-wider text-slate-100 drop-shadow-md">
              {timeStr}
            </div>
            <div className="text-xs font-mono text-slate-400">
              {dateStr}
            </div>
          </div>

          <button
            id="exit-kiosk-btn"
            onClick={onExitKiosk}
            className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-[#141e30] border border-[#263b59] hover:bg-[#1a2840] text-slate-300 hover:text-cyan-300 transition-colors text-xs font-mono cursor-pointer"
            title="返回标准运维控制台"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>退出大屏</span>
          </button>
        </div>
      </header>

      {/* Main Kiosk Dashboard Grid */}
      <main className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 mt-6">
        {/* Left 8 Cols: KPIs & Big Topology Matrix */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          {/* Big KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
            {/* Card 1: 在线资源 */}
            <div className="bg-[#0e1626] border border-[#1d2d46] rounded-xl p-5 shadow-lg relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">
                  在线资源
                </span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[11px] font-mono border border-emerald-500/30">
                  运行正常
                </span>
              </div>
              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-4xl sm:text-5xl font-mono font-black text-slate-100">
                  42
                </span>
                <span className="text-xs text-slate-400 font-mono">个实例</span>
              </div>
              <div className="mt-2 text-xs text-emerald-400 font-mono flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>核心链路健康度 95.2%</span>
              </div>
            </div>

            {/* Card 2: 异常资源 */}
            <div className="bg-[#18111a] border border-rose-900/60 rounded-xl p-5 shadow-lg relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-rose-300 uppercase tracking-wider">
                  异常资源
                </span>
                <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 text-[11px] font-mono border border-rose-500/40 animate-pulse">
                  需要关注
                </span>
              </div>
              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-4xl sm:text-5xl font-mono font-black text-rose-400 drop-shadow-[0_0_12px_rgba(244,63,94,0.4)]">
                  02
                </span>
                <span className="text-xs text-rose-300/80 font-mono">处告警</span>
              </div>
              <div className="mt-2 text-xs text-rose-400 font-mono flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>1 端口故障 · 1 延迟过高</span>
              </div>
            </div>

            {/* Card 3: 实时网络吞吐 */}
            <div className="bg-[#0e1626] border border-[#1d2d46] rounded-xl p-5 shadow-lg relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">
                  实时网络吞吐
                </span>
                <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 text-[11px] font-mono border border-cyan-500/30">
                  带宽平稳
                </span>
              </div>
              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-4xl sm:text-5xl font-mono font-black text-cyan-300">
                  1.84
                </span>
                <span className="text-xs text-slate-400 font-mono">Gbps</span>
              </div>
              <div className="mt-2 text-xs text-cyan-400 font-mono flex items-center gap-1">
                <Zap className="w-3.5 h-3.5" />
                <span>峰值储备充足 (38%)</span>
              </div>
            </div>

            {/* Card 4: 今日活动流 */}
            <div className="bg-[#0e1626] border border-[#1d2d46] rounded-xl p-5 shadow-lg relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">
                  事件审计流
                </span>
                <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[11px] font-mono border border-purple-500/30">
                  飞行记录仪
                </span>
              </div>
              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-4xl sm:text-5xl font-mono font-black text-slate-100">
                  128
                </span>
                <span className="text-xs text-slate-400 font-mono">条事件</span>
              </div>
              <div className="mt-2 text-xs text-purple-400 font-mono flex items-center gap-1">
                <Activity className="w-3.5 h-3.5" />
                <span>3 次自愈补偿完成</span>
              </div>
            </div>
          </div>

          {/* System Topology Matrix (Kiosk Edition) */}
          <div className="bg-[#0c1322] border border-[#1b2a42] rounded-xl p-5 shadow-xl flex-1 flex flex-col">
            <div className="flex items-center justify-between pb-4 border-b border-[#18253a]">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                <h2 className="text-base font-bold font-mono tracking-wide text-slate-100">
                  系统接线概览 (TOPOLOGY MATRIX)
                </h2>
              </div>
              <div className="text-xs font-mono text-slate-400">
                远距离大屏展示 · 实时连通性探测
              </div>
            </div>

            {/* Three Column Matrix */}
            <div className="mt-5 flex-1 flex flex-col justify-around gap-4">
              {resources.slice(0, 4).map((item) => {
                const isAlive = item.status === 'alive';
                const isDead = item.status === 'dead';
                const strokeColor = isAlive ? '#55C98A' : isDead ? '#D95D5D' : '#D9A441';

                return (
                  <div
                    key={item.id}
                    className="grid grid-cols-12 items-center gap-3 p-3.5 rounded-xl bg-[#10182b] border border-[#1e2f4a]"
                  >
                    {/* Public Ingress */}
                    <div className="col-span-3 font-mono">
                      <div className="text-base font-bold text-cyan-300">{item.ingress}</div>
                      <div className="text-xs text-slate-400 truncate">{item.name}</div>
                    </div>

                    {/* SVG Flow 1 */}
                    <div className="col-span-2">
                      <svg className="w-full h-8 overflow-visible" viewBox="0 0 80 20">
                        <path
                          d="M 2 10 L 76 10"
                          stroke={strokeColor}
                          strokeWidth="2.5"
                          fill="none"
                          className={isAlive ? 'animate-flow-dash' : ''}
                        />
                        <circle cx="76" cy="10" r="3" fill={strokeColor} />
                      </svg>
                    </div>

                    {/* Engine Box */}
                    <div className="col-span-2 flex justify-center">
                      <div className={`px-3 py-1.5 rounded-lg border text-center font-mono w-full ${
                        isAlive
                          ? 'bg-[#132338] border-emerald-500/40 text-emerald-200'
                          : isDead
                          ? 'bg-rose-950/40 border-rose-600/50 text-rose-200'
                          : 'bg-amber-950/40 border-amber-600/50 text-amber-200'
                      }`}>
                        <div className="text-xs font-bold">{item.engine}</div>
                        <div className="text-[10px] opacity-75">{item.protocol}</div>
                      </div>
                    </div>

                    {/* SVG Flow 2 */}
                    <div className="col-span-2">
                      <svg className="w-full h-8 overflow-visible" viewBox="0 0 80 20">
                        <path
                          d="M 2 10 L 76 10"
                          stroke={strokeColor}
                          strokeWidth="2.5"
                          fill="none"
                          className={isAlive ? 'animate-flow-dash' : ''}
                        />
                        <circle cx="76" cy="10" r="3" fill={strokeColor} />
                      </svg>
                    </div>

                    {/* Target */}
                    <div className="col-span-3 text-right font-mono">
                      <div className="text-base font-bold text-slate-100">{item.target}</div>
                      <div className={`text-xs ${isAlive ? 'text-emerald-400' : isDead ? 'text-rose-400' : 'text-amber-400'}`}>
                        {item.latency}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right 4 Cols: Anomaly Alert Stream (异常告警) */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          <div className="bg-[#12111c] border border-rose-900/40 rounded-xl p-5 shadow-xl flex-1 flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-rose-950/60">
              <div className="flex items-center gap-2 text-rose-400">
                <AlertTriangle className="w-5 h-5 animate-bounce" />
                <h3 className="text-base font-bold font-mono tracking-wide">
                  异常告警 (ANOMALY ALERTS)
                </h3>
              </div>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-rose-950/80 text-rose-300 border border-rose-800/60">
                优先展示
              </span>
            </div>

            {/* List of active anomalies */}
            <div className="mt-4 space-y-3.5 flex-1 overflow-y-auto">
              {/* Alert 1 */}
              <div className="p-4 rounded-xl bg-[#1d1219] border border-rose-800/70 relative overflow-hidden">
                <div className="flex items-start justify-between gap-2">
                  <div className="font-mono text-sm font-bold text-rose-300">
                    转发服务异常
                  </div>
                  <span className="text-xs font-mono text-rose-400/80">刚刚</span>
                </div>
                <div className="text-xs font-mono text-slate-300 mt-1.5">
                  :7001 · 连接不可用 (Timeout)
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  微内核虚拟机 SmolVM 实例离线，TCP 探针重试 3 次均超时无响应。
                </p>
                <div className="mt-2.5 flex items-center justify-between text-[11px] font-mono text-rose-400">
                  <span>影响节点: smolvm:v1</span>
                  <span className="underline">待处置</span>
                </div>
              </div>

              {/* Alert 2 */}
              <div className="p-4 rounded-xl bg-[#1d1512] border border-amber-800/70 relative overflow-hidden">
                <div className="flex items-start justify-between gap-2">
                  <div className="font-mono text-sm font-bold text-amber-300">
                    容器状态异常 / 复制延迟
                  </div>
                  <span className="text-xs font-mono text-amber-400/80">2 分钟前</span>
                </div>
                <div className="text-xs font-mono text-slate-300 mt-1.5">
                  c1 / db:3306 · 需要检查
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  MySQL 代理层监控到线程负载偏高，部分并发查询排队超过 80ms。
                </p>
                <div className="mt-2.5 flex items-center justify-between text-[11px] font-mono text-amber-400">
                  <span>自动启用备用只读路由</span>
                  <span>已告警通知 DBA</span>
                </div>
              </div>

              {/* Alert 3: Activity warning */}
              <div className="p-4 rounded-xl bg-[#11192b] border border-cyan-900/60 relative overflow-hidden">
                <div className="flex items-start justify-between gap-2">
                  <div className="font-mono text-sm font-bold text-cyan-300">
                    自愈补偿事件已触发
                  </div>
                  <span className="text-xs font-mono text-slate-400">12 分钟前</span>
                </div>
                <div className="text-xs font-mono text-slate-300 mt-1.5">
                  dev.xxx → c1:7002 · Caddy 自动重启
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  上游 Keep-Alive 管道瞬时断开后，系统守护进程已成功重建连接。
                </p>
              </div>
            </div>

            {/* Kiosk status indicator footnote */}
            <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono text-slate-400">
              <div className="flex items-center gap-1.5">
                <RefreshCw className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                <span>后台守护引擎持续自愈</span>
              </div>
              <span className="text-slate-500">NO HUMAN INTERVENTION</span>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
