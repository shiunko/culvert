'use client';

import React from 'react';
import { Server, Cpu, HardDrive, Network, ShieldCheck, AlertCircle, RefreshCw } from 'lucide-react';

export const ManagementView: React.FC = () => {
  return (
    <div id="management-view" className="space-y-6">
      {/* Overview Card */}
      <div className="bg-[#121824] border border-[#1e2a3e] rounded-xl p-5 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-[#1b263b]">
          <div>
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Server className="w-5 h-5 text-cyan-400" />
              主机节点与资源分配管理
            </h2>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              集群计算算力调度 · 端口池配额划分
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono px-3 py-1 rounded-full bg-emerald-950/60 border border-emerald-500/40 text-emerald-300">
              ● 调度核心正常
            </span>
          </div>
        </div>

        {/* Nodes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-5">
          {/* Node 1 */}
          <div className="bg-[#0f1624] border border-[#1d2b40] rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-mono text-sm font-bold text-slate-200">node-primary-01</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-900/40 text-emerald-300 border border-emerald-700/50">
                主控节点
              </span>
            </div>
            <div className="space-y-2 text-xs font-mono">
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>CPU 占用</span>
                  <span className="text-slate-200">62% (6.2 / 10 Cores)</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div className="w-[62%] h-full bg-cyan-400 rounded-full" />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>内存配额</span>
                  <span className="text-slate-200">19.8 / 32 GB (61.8%)</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div className="w-[61.8%] h-full bg-indigo-400 rounded-full" />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>端口分配</span>
                  <span className="text-slate-200">41 / 64 个映射</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div className="w-[64%] h-full bg-emerald-400 rounded-full" />
                </div>
              </div>
            </div>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>运行容器: 6 实例</span>
              <span>健康度: 99.8%</span>
            </div>
          </div>

          {/* Node 2 */}
          <div className="bg-[#0f1624] border border-[#1d2b40] rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-mono text-sm font-bold text-slate-200">node-worker-c1</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-900/40 text-amber-300 border border-amber-700/50">
                负载偏高
              </span>
            </div>
            <div className="space-y-2 text-xs font-mono">
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>CPU 占用</span>
                  <span className="text-amber-400">78% (12.4 / 16 Cores)</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div className="w-[78%] h-full bg-amber-400 rounded-full" />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>内存配额</span>
                  <span className="text-slate-200">26.2 / 32 GB (81.8%)</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div className="w-[81.8%] h-full bg-amber-400 rounded-full" />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>端口分配</span>
                  <span className="text-slate-200">18 / 32 个映射</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div className="w-[56%] h-full bg-cyan-400 rounded-full" />
                </div>
              </div>
            </div>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>运行容器: 2 实例</span>
              <span className="text-amber-400">内存限制告警</span>
            </div>
          </div>

          {/* Node 3 */}
          <div className="bg-[#0f1624] border border-[#1d2b40] rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-mono text-sm font-bold text-slate-200">node-edge-vm02</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-900/40 text-indigo-300 border border-indigo-700/50">
                微虚拟机边缘
              </span>
            </div>
            <div className="space-y-2 text-xs font-mono">
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>CPU 占用</span>
                  <span className="text-slate-200">24% (1.9 / 8 Cores)</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div className="w-[24%] h-full bg-emerald-400 rounded-full" />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>内存配额</span>
                  <span className="text-slate-200">4.1 / 16 GB (25.6%)</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div className="w-[25.6%] h-full bg-emerald-400 rounded-full" />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>端口分配</span>
                  <span className="text-slate-200">2 / 16 个映射</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div className="w-[12.5%] h-full bg-indigo-400 rounded-full" />
                </div>
              </div>
            </div>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>运行 VM: 2 实例</span>
              <span>健康度: 100%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
