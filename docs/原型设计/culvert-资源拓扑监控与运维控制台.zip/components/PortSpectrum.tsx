'use client';

import React, { useState } from 'react';
import { PortSegment, ResourceItem } from '@/lib/mock-data';
import { Layers, ShieldAlert, CheckCircle, Info, ExternalLink } from 'lucide-react';

interface PortSpectrumProps {
  portSegments: PortSegment[];
  resources: ResourceItem[];
  onSelectResourceById?: (resourceId: string) => void;
  hoveredResourceId?: string | null;
  setHoveredResourceId?: (id: string | null) => void;
}

export const PortSpectrum: React.FC<PortSpectrumProps> = ({
  portSegments,
  resources,
  onSelectResourceById,
  hoveredResourceId,
  setHoveredResourceId,
}) => {
  const [selectedProtocol, setSelectedProtocol] = useState<'ALL' | 'TCP' | 'UDP'>('ALL');
  const [hoveredPort, setHoveredPort] = useState<PortSegment | null>(null);

  // Filter segments based on protocol
  const filteredSegments = portSegments.filter((seg) => {
    if (selectedProtocol === 'ALL') return true;
    return seg.protocol === selectedProtocol;
  });

  const getSegmentColor = (segment: PortSegment) => {
    if (segment.isReserved) {
      return {
        bg: 'bg-slate-700/60',
        border: 'border-slate-500/40',
        text: 'text-slate-300',
        isStriped: true,
      };
    }
    switch (segment.status) {
      case 'alive':
        return {
          bg: 'bg-[#55C98A]',
          border: 'border-emerald-400',
          text: 'text-emerald-950 font-bold',
          isStriped: false,
        };
      case 'dead':
        return {
          bg: 'bg-[#D95D5D]',
          border: 'border-rose-400',
          text: 'text-rose-950 font-bold',
          isStriped: false,
        };
      case 'unknown':
        return {
          bg: 'bg-[#D9A441]',
          border: 'border-amber-400',
          text: 'text-amber-950 font-bold',
          isStriped: false,
        };
      case 'disabled':
        return {
          bg: 'bg-[#64748B]',
          border: 'border-slate-500',
          text: 'text-slate-900 font-bold',
          isStriped: false,
        };
      default:
        return {
          bg: 'bg-[#5B9BEB]',
          border: 'border-blue-400',
          text: 'text-blue-950 font-bold',
          isStriped: false,
        };
    }
  };

  const handleSegmentClick = (segment: PortSegment) => {
    if (segment.resourceId && onSelectResourceById) {
      onSelectResourceById(segment.resourceId);
    }
  };

  return (
    <div id="port-spectrum-card" className="bg-[#121824] border border-[#1e2a3e] rounded-xl p-5 shadow-lg relative">
      {/* Header with Title & Protocol Filter */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-[#1b263b]">
        <div className="flex items-center gap-2.5">
          <Layers className="w-4 h-4 text-cyan-400" />
          <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
            端口频谱
            <span className="text-xs font-mono font-normal text-slate-400 px-2 py-0.5 rounded bg-[#182234] border border-[#223249]">
              Port Spectrum
            </span>
          </h3>
          <span className="text-xs font-mono text-slate-400 ml-1">范围: 0 – 65535</span>
        </div>

        <div className="flex items-center gap-2">
          {/* Protocol Toggle */}
          <div className="inline-flex rounded-lg p-0.5 bg-[#0e1420] border border-[#1f2b3e] text-xs font-mono">
            <button
              id="filter-proto-all"
              onClick={() => setSelectedProtocol('ALL')}
              className={`px-2.5 py-1 rounded transition-all cursor-pointer ${
                selectedProtocol === 'ALL'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              全部协议
            </button>
            <button
              id="filter-proto-tcp"
              onClick={() => setSelectedProtocol('TCP')}
              className={`px-2.5 py-1 rounded transition-all cursor-pointer ${
                selectedProtocol === 'TCP'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              TCP
            </button>
            <button
              id="filter-proto-udp"
              onClick={() => setSelectedProtocol('UDP')}
              className={`px-2.5 py-1 rounded transition-all cursor-pointer ${
                selectedProtocol === 'UDP'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              UDP
            </button>
          </div>
        </div>
      </div>

      {/* Spectrum Visualization Bar */}
      <div className="space-y-2">
        {/* Band Headers */}
        <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 px-1">
          <span className="text-cyan-400 font-medium flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
            低端口区间 (0 - 1024 视觉放大区)
          </span>
          <span className="text-slate-500">动态与高端口区间 (1025 - 65535)</span>
        </div>

        {/* The Track Container */}
        <div className="relative w-full h-12 rounded-lg bg-[#0a0f19] border border-[#223147] p-1 flex items-center gap-1 overflow-hidden shadow-inner">
          {/* We define stylized blocks across the 0-65535 spectrum */}
          {/* Low Port Magnified Zone (0 - 1024) -> allocated 45% visual width */}
          <div className="relative h-full flex items-center gap-1 bg-[#101929]/70 rounded px-1.5 border border-[#1e2f47]" style={{ width: '45%' }}>
            {filteredSegments
              .filter((s) => s.startPort <= 1024)
              .map((seg) => {
                const colors = getSegmentColor(seg);
                const isHovered = hoveredPort?.id === seg.id || hoveredResourceId === seg.resourceId;

                return (
                  <button
                    key={seg.id}
                    id={`port-seg-${seg.id}`}
                    onClick={() => handleSegmentClick(seg)}
                    onMouseEnter={() => {
                      setHoveredPort(seg);
                      if (seg.resourceId && setHoveredResourceId) setHoveredResourceId(seg.resourceId);
                    }}
                    onMouseLeave={() => {
                      setHoveredPort(null);
                      if (setHoveredResourceId) setHoveredResourceId(null);
                    }}
                    className={`h-full min-w-[32px] flex-1 rounded px-1 flex flex-col items-center justify-center transition-all cursor-pointer border ${
                      colors.bg
                    } ${colors.border} ${colors.text} ${
                      colors.isStriped ? 'striped-reserved' : ''
                    } ${isHovered ? 'ring-2 ring-cyan-400 scale-[1.03] z-10' : 'opacity-90 hover:opacity-100'}`}
                    title={seg.label}
                  >
                    <span className="text-[10px] font-mono leading-none tracking-tight truncate">
                      :{seg.startPort}
                    </span>
                    <span className="text-[9px] font-mono opacity-80 leading-none mt-0.5">
                      {seg.protocol}
                    </span>
                  </button>
                );
              })}

            {/* Empty space in low range */}
            <div className="flex-1 h-full flex items-center justify-center text-[9px] font-mono text-slate-600 border border-dashed border-slate-800 rounded bg-[#0b101c]">
              空闲
            </div>
          </div>

          {/* Medium Port Zone (1025 - 8192) -> allocated 30% visual width */}
          <div className="relative h-full flex items-center gap-1 bg-[#101929]/50 rounded px-1.5 border border-[#1b2a40]" style={{ width: '30%' }}>
            {filteredSegments
              .filter((s) => s.startPort > 1024 && s.startPort <= 8192)
              .map((seg) => {
                const colors = getSegmentColor(seg);
                const isHovered = hoveredPort?.id === seg.id || hoveredResourceId === seg.resourceId;

                return (
                  <button
                    key={seg.id}
                    id={`port-seg-${seg.id}`}
                    onClick={() => handleSegmentClick(seg)}
                    onMouseEnter={() => {
                      setHoveredPort(seg);
                      if (seg.resourceId && setHoveredResourceId) setHoveredResourceId(seg.resourceId);
                    }}
                    onMouseLeave={() => {
                      setHoveredPort(null);
                      if (setHoveredResourceId) setHoveredResourceId(null);
                    }}
                    className={`h-full min-w-[26px] flex-1 rounded px-1 flex flex-col items-center justify-center transition-all cursor-pointer border ${
                      colors.bg
                    } ${colors.border} ${colors.text} ${
                      colors.isStriped ? 'striped-reserved' : ''
                    } ${isHovered ? 'ring-2 ring-cyan-400 scale-[1.03] z-10' : 'opacity-90 hover:opacity-100'}`}
                  >
                    <span className="text-[10px] font-mono leading-none tracking-tight truncate">
                      :{seg.startPort}
                    </span>
                    <span className="text-[9px] font-mono opacity-80 leading-none mt-0.5">
                      {seg.protocol}
                    </span>
                  </button>
                );
              })}
          </div>

          {/* High Port & Reserved Zone (8193 - 65535) -> allocated 25% visual width */}
          <div className="relative h-full flex items-center gap-1 bg-[#101929]/30 rounded px-1.5 border border-[#162337]" style={{ width: '25%' }}>
            {filteredSegments
              .filter((s) => s.startPort > 8192)
              .map((seg) => {
                const colors = getSegmentColor(seg);
                const isHovered = hoveredPort?.id === seg.id || hoveredResourceId === seg.resourceId;

                return (
                  <button
                    key={seg.id}
                    id={`port-seg-${seg.id}`}
                    onClick={() => handleSegmentClick(seg)}
                    onMouseEnter={() => {
                      setHoveredPort(seg);
                      if (seg.resourceId && setHoveredResourceId) setHoveredResourceId(seg.resourceId);
                    }}
                    onMouseLeave={() => {
                      setHoveredPort(null);
                      if (setHoveredResourceId) setHoveredResourceId(null);
                    }}
                    className={`h-full flex-1 rounded px-1 flex flex-col items-center justify-center transition-all cursor-pointer border ${
                      colors.bg
                    } ${colors.border} ${colors.text} ${
                      colors.isStriped ? 'striped-reserved' : ''
                    } ${isHovered ? 'ring-2 ring-cyan-400 scale-[1.03] z-10' : 'opacity-85 hover:opacity-100'}`}
                  >
                    <span className="text-[10px] font-mono leading-none tracking-tight truncate">
                      {seg.isReserved ? '预留段' : `:${seg.startPort}`}
                    </span>
                    <span className="text-[9px] font-mono opacity-80 leading-none mt-0.5">
                      {seg.startPort >= 10000 ? `${Math.round(seg.startPort / 1000)}k` : seg.startPort}
                    </span>
                  </button>
                );
              })}
          </div>
        </div>

        {/* Axis Ticks */}
        <div className="flex justify-between items-center text-[10px] font-mono text-slate-500 px-1 pt-0.5">
          <div className="flex flex-col items-start">
            <span className="h-1.5 w-[1px] bg-slate-600 mb-0.5" />
            <span>0</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="h-1.5 w-[1px] bg-slate-600 mb-0.5" />
            <span>1k (放大分界)</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="h-1.5 w-[1px] bg-slate-600 mb-0.5" />
            <span>8k</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="h-1.5 w-[1px] bg-slate-600 mb-0.5" />
            <span>32k</span>
          </div>
          <div className="flex flex-col items-end">
            <span className="h-1.5 w-[1px] bg-slate-600 mb-0.5" />
            <span>65k</span>
          </div>
        </div>

        {/* Interactive Hover Tooltip details bar */}
        <div className="min-h-[44px] rounded-lg bg-[#0e1421] border border-[#1b263b] px-3 py-2 flex items-center justify-between text-xs">
          {hoveredPort ? (
            <div className="flex flex-wrap items-center gap-3">
              <span className="font-mono font-bold text-cyan-300 text-sm">
                {hoveredPort.label}
              </span>
              <span className="text-slate-500">|</span>
              <span className="text-slate-300">
                所属资源: <span className="text-slate-100 font-mono font-medium">{hoveredPort.service}</span>
              </span>
              <span className="text-slate-500">|</span>
              <span className="text-slate-300">
                负责人: <span className="text-indigo-300 font-mono">{hoveredPort.owner}</span>
              </span>
              <span className="text-slate-500">|</span>
              <span className="text-slate-300">
                状态:
                {hoveredPort.isReserved ? (
                  <span className="ml-1 text-slate-300 bg-slate-700/50 px-1.5 py-0.5 rounded border border-slate-600">系统预留</span>
                ) : hoveredPort.status === 'alive' ? (
                  <span className="ml-1 text-emerald-400 bg-emerald-950/40 px-1.5 py-0.5 rounded border border-emerald-700/60">运行正常</span>
                ) : hoveredPort.status === 'dead' ? (
                  <span className="ml-1 text-rose-400 bg-rose-950/40 px-1.5 py-0.5 rounded border border-rose-700/60">端口不可达 (异常)</span>
                ) : (
                  <span className="ml-1 text-amber-400 bg-amber-950/40 px-1.5 py-0.5 rounded border border-amber-700/60">警告/降级</span>
                )}
              </span>
              {hoveredPort.resourceId && (
                <span className="text-cyan-400 flex items-center gap-1 text-[11px] font-medium ml-1">
                  (点击跳转详情 <ExternalLink className="w-3 h-3" />)
                </span>
              )}
            </div>
          ) : (
            <div className="text-slate-400 flex items-center gap-2">
              <Info className="w-3.5 h-3.5 text-cyan-400" />
              <span>悬停上方色块查看端口详细分配、关联资源与负责人，点击色块快速跳转定位。</span>
            </div>
          )}
        </div>

        {/* Legend & Design Note */}
        <div className="pt-2 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-[#55C98A]" />
              <span>已占用正常</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-[#D95D5D]" />
              <span>异常冲突</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-[#D9A441]" />
              <span>高延迟/告警</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-slate-700 border border-slate-500 striped-reserved" />
              <span>预留端口范围 (斜纹)</span>
            </div>
          </div>

          <div className="text-[11px] font-mono text-cyan-400/90 bg-cyan-950/20 px-2 py-1 rounded border border-cyan-900/40">
            * 提示：低端口区间视觉放大显示，便于识别密集占用，不代表实际端口数学比例。
          </div>
        </div>
      </div>
    </div>
  );
};
