'use client';

import React, { useState, useEffect, useRef } from 'react';
import { ResourceItem, ResourceStatus, ResourceType } from '@/lib/mock-data';
import { Search, Plus, Filter, CheckCircle2, AlertTriangle, XCircle, ArrowRight, ExternalLink, ShieldCheck, Activity, Terminal } from 'lucide-react';

interface ResourceListProps {
  type: ResourceType | 'all';
  title: string;
  resources: ResourceItem[];
  highlightedResourceId?: string | null;
  onOpenExposeDrawer: () => void;
  onClearHighlight?: () => void;
}

export const ResourceList: React.FC<ResourceListProps> = ({
  type,
  title,
  resources,
  highlightedResourceId,
  onOpenExposeDrawer,
  onClearHighlight,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | ResourceStatus>('ALL');
  const rowRefs = useRef<{ [key: string]: HTMLTableRowElement | null }>({});

  const filteredResources = resources.filter((item) => {
    if (type !== 'all' && item.type !== type) return false;
    if (statusFilter !== 'ALL' && item.status !== statusFilter) return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      item.name.toLowerCase().includes(q) ||
      item.ingress.toLowerCase().includes(q) ||
      item.engine.toLowerCase().includes(q) ||
      item.target.toLowerCase().includes(q) ||
      item.owner.toLowerCase().includes(q)
    );
  });

  // Auto-scroll and focus if there is a highlighted resource id
  useEffect(() => {
    if (highlightedResourceId && rowRefs.current[highlightedResourceId]) {
      const el = rowRefs.current[highlightedResourceId];
      el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      const timer = setTimeout(() => {
        if (onClearHighlight) onClearHighlight();
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [highlightedResourceId, onClearHighlight]);

  const getStatusBadge = (status: ResourceStatus) => {
    switch (status) {
      case 'alive':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-mono bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            运行中
          </span>
        );
      case 'dead':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-mono bg-rose-500/15 text-rose-300 border border-rose-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-pulse" />
            异常不可达
          </span>
        );
      case 'disabled':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-mono bg-slate-800 text-slate-400 border border-slate-700">
            <span className="w-1.5 h-1.5 rounded-full bg-slate-500" />
            已禁用
          </span>
        );
      case 'unknown':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-mono bg-amber-500/15 text-amber-300 border border-amber-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            警告/未知
          </span>
        );
    }
  };

  return (
    <div id="resource-list-container" className="space-y-4">
      {/* Action & Filter Header */}
      <div className="bg-[#121824] border border-[#1e2a3e] rounded-xl p-4 shadow-lg flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <span>{title}</span>
            <span className="text-xs font-mono font-normal px-2 py-0.5 rounded bg-[#192436] border border-[#23334d] text-cyan-300">
              共 {filteredResources.length} 项
            </span>
          </h2>

          {highlightedResourceId && (
            <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/50 text-cyan-300 animate-pulse">
              已定位并高亮目标资源
            </span>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="搜索端口、引擎、目标..."
              className="pl-9 pr-3 py-1.5 rounded-lg bg-[#0c121d] border border-[#22334c] text-xs font-mono text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500 w-48 sm:w-60"
            />
          </div>

          {/* Status Filter */}
          <div className="inline-flex rounded-lg p-0.5 bg-[#0e1420] border border-[#1f2b3e] text-xs font-mono">
            <button
              onClick={() => setStatusFilter('ALL')}
              className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                statusFilter === 'ALL' ? 'bg-slate-700 text-slate-100' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              全部
            </button>
            <button
              onClick={() => setStatusFilter('alive')}
              className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                statusFilter === 'alive' ? 'bg-emerald-950/80 text-emerald-300' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              运行中
            </button>
            <button
              onClick={() => setStatusFilter('dead')}
              className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                statusFilter === 'dead' ? 'bg-rose-950/80 text-rose-300' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              异常
            </button>
          </div>

          {/* Action Button to open Drawer */}
          <button
            id="open-expose-drawer-btn"
            onClick={onOpenExposeDrawer}
            className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-mono text-xs font-medium flex items-center gap-1.5 shadow-md shadow-cyan-950/40 transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>暴露新端口</span>
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-[#121824] border border-[#1e2a3e] rounded-xl overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-sans">
            <thead className="bg-[#0e1420] text-slate-400 font-mono text-[11px] uppercase tracking-wider border-b border-[#1b263b]">
              <tr>
                <th className="px-4 py-3">资源名称</th>
                <th className="px-4 py-3">公网入口 (Ingress)</th>
                <th className="px-4 py-3">服务引擎 (Engine)</th>
                <th className="px-4 py-3">内网目标 (Target)</th>
                <th className="px-4 py-3">协议</th>
                <th className="px-4 py-3">延迟 / 吞吐</th>
                <th className="px-4 py-3">状态</th>
                <th className="px-4 py-3">负责人</th>
                <th className="px-4 py-3 text-right">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#182335]">
              {filteredResources.length > 0 ? (
                filteredResources.map((item) => {
                  const isHighlighted = highlightedResourceId === item.id;

                  return (
                    <tr
                      key={item.id}
                      ref={(el) => {
                        rowRefs.current[item.id] = el;
                      }}
                      id={`resource-row-${item.id}`}
                      className={`transition-colors ${
                        isHighlighted
                          ? 'animate-target-highlight bg-cyan-950/40'
                          : 'hover:bg-[#151e2e]'
                      }`}
                    >
                      {/* Name & Details */}
                      <td className="px-4 py-3.5">
                        <div className="font-medium text-slate-100">{item.name}</div>
                        <div className="text-[11px] text-slate-400 truncate max-w-xs">{item.description}</div>
                        {item.errorMsg && (
                          <div className="mt-1 text-[11px] text-rose-400 font-mono flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3 shrink-0" />
                            <span>{item.errorMsg}</span>
                          </div>
                        )}
                      </td>

                      {/* Ingress */}
                      <td className="px-4 py-3.5 font-mono text-cyan-300 font-semibold">
                        {item.ingress}
                      </td>

                      {/* Engine */}
                      <td className="px-4 py-3.5 font-mono text-indigo-300 font-medium">
                        <span className="px-2 py-0.5 rounded bg-[#182337] border border-slate-700/60">
                          {item.engine}
                        </span>
                      </td>

                      {/* Target */}
                      <td className="px-4 py-3.5 font-mono text-slate-200">
                        {item.target}
                      </td>

                      {/* Protocol */}
                      <td className="px-4 py-3.5 font-mono text-slate-400">
                        {item.protocol}
                      </td>

                      {/* Latency / Throughput */}
                      <td className="px-4 py-3.5 font-mono">
                        <div className={item.status === 'dead' ? 'text-rose-400' : 'text-emerald-400'}>
                          {item.latency}
                        </div>
                        <div className="text-[11px] text-slate-400">{item.throughput}</div>
                      </td>

                      {/* Status */}
                      <td className="px-4 py-3.5">
                        {getStatusBadge(item.status)}
                      </td>

                      {/* Owner */}
                      <td className="px-4 py-3.5 font-mono text-slate-300">
                        {item.owner}
                      </td>

                      {/* Actions */}
                      <td className="px-4 py-3.5 text-right font-mono">
                        <button
                          onClick={() => alert(`模拟测试: 正在探测 ${item.ingress} -> ${item.target} 连通性`)}
                          className="px-2.5 py-1 rounded bg-[#182337] hover:bg-[#22334d] text-cyan-300 hover:text-cyan-200 text-xs border border-slate-700/70 transition-colors cursor-pointer"
                        >
                          连通性测试
                        </button>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400 font-mono">
                    未找到匹配资源规则
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
