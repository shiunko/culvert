'use client';

import React, { useState } from 'react';
import { ResourceItem, PortSegment } from '@/lib/mock-data';
import { X, Plus, AlertCircle, CheckCircle2, ShieldAlert, ArrowRight } from 'lucide-react';

interface ExposePortDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onAddResource: (resource: ResourceItem) => void;
  existingResources: ResourceItem[];
}

export const ExposePortDrawer: React.FC<ExposePortDrawerProps> = ({
  isOpen,
  onClose,
  onAddResource,
  existingResources,
}) => {
  const [portInput, setPortInput] = useState('8088');
  const [name, setName] = useState('新暴露微服务网关');
  const [engine, setEngine] = useState('socat');
  const [target, setTarget] = useState('10.0.0.9:8080');
  const [protocol, setProtocol] = useState<'TCP' | 'UDP' | 'HTTP'>('TCP');
  const [owner, setOwner] = useState('admin');
  const [description, setDescription] = useState('临时转发路由，供前端联调测试');

  if (!isOpen) return null;

  const portNum = parseInt(portInput, 10);
  const isPortConflict = existingResources.some((r) => r.port === portNum);
  const isReserved =
    (portNum >= 10000 && portNum <= 11500) ||
    (portNum >= 20000 && portNum <= 22000) ||
    (portNum >= 49152 && portNum <= 52000);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isNaN(portNum) || portNum <= 0 || portNum > 65535) {
      alert('请输入有效的端口号 (1-65535)');
      return;
    }

    const newRes: ResourceItem = {
      id: `res-${Date.now()}`,
      name,
      ingress: `:${portNum}`,
      engine,
      target,
      type: 'forward',
      status: 'alive',
      port: portNum,
      protocol,
      owner,
      latency: '2.4ms',
      throughput: '12 MB/s',
      uptime: '刚刚启动',
      description,
      updatedAt: '刚刚',
    };

    onAddResource(newRes);
    onClose();
  };

  return (
    <div
      id="expose-port-drawer-backdrop"
      className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-xs transition-opacity"
      onClick={onClose}
    >
      <div
        id="expose-port-drawer"
        className="w-full max-w-md bg-[#0f1726] border-l border-[#223550] h-full shadow-2xl flex flex-col justify-between overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div>
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-[#1c2a3e] bg-[#121c2e]">
            <div>
              <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Plus className="w-4 h-4 text-cyan-400" />
                暴露端口 / 创建转发
              </h2>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                抽屉式快速运维表单 · 联动端口频谱
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-[#1c2b42] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            {/* 规则名称 */}
            <div>
              <label className="block text-xs font-mono text-slate-300 mb-1">
                规则名称
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="w-full px-3 py-2 rounded-lg bg-[#0b101c] border border-[#21324c] text-sm text-slate-100 focus:outline-none focus:border-cyan-500 font-mono"
              />
            </div>

            {/* 公网入口端口 */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-mono text-slate-300">
                  公网入口端口 (0 - 65535)
                </label>
                <span className="text-[11px] font-mono text-slate-400">
                  自动校验频谱冲突
                </span>
              </div>
              <div className="relative">
                <span className="absolute left-3 top-2 text-slate-500 font-mono text-sm">:</span>
                <input
                  type="number"
                  min="1"
                  max="65535"
                  value={portInput}
                  onChange={(e) => setPortInput(e.target.value)}
                  required
                  className={`w-full pl-7 pr-3 py-2 rounded-lg bg-[#0b101c] border text-sm font-mono text-slate-100 focus:outline-none ${
                    isPortConflict
                      ? 'border-rose-500 focus:border-rose-400'
                      : isReserved
                      ? 'border-amber-500 focus:border-amber-400'
                      : 'border-[#21324c] focus:border-cyan-500'
                  }`}
                />
              </div>

              {/* Conflict / Reserved Status Feedback */}
              {isPortConflict && (
                <div className="mt-1.5 flex items-center gap-1.5 text-xs text-rose-400 font-mono">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>端口已占用！请选择其他空闲端口以避免冲突。</span>
                </div>
              )}
              {isReserved && !isPortConflict && (
                <div className="mt-1.5 flex items-center gap-1.5 text-xs text-amber-400 font-mono">
                  <ShieldAlert className="w-3.5 h-3.5" />
                  <span>注意：当前端口位于系统预留段，建议优先使用常规段。</span>
                </div>
              )}
              {!isPortConflict && !isReserved && portNum > 0 && (
                <div className="mt-1.5 flex items-center gap-1.5 text-xs text-emerald-400 font-mono">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>端口可用，无冲突记录。</span>
                </div>
              )}
            </div>

            {/* 服务引擎 & 协议 */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-mono text-slate-300 mb-1">
                  服务引擎
                </label>
                <select
                  value={engine}
                  onChange={(e) => setEngine(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#0b101c] border border-[#21324c] text-sm text-slate-100 focus:outline-none focus:border-cyan-500 font-mono"
                >
                  <option value="socat">socat (TCP代理)</option>
                  <option value="caddy">caddy (HTTP/TLS)</option>
                  <option value="envoy">envoy (网关反代)</option>
                  <option value="nginx">nginx (标准负载均衡)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-300 mb-1">
                  传输协议
                </label>
                <select
                  value={protocol}
                  onChange={(e) => setProtocol(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-lg bg-[#0b101c] border border-[#21324c] text-sm text-slate-100 focus:outline-none focus:border-cyan-500 font-mono"
                >
                  <option value="TCP">TCP</option>
                  <option value="UDP">UDP</option>
                  <option value="HTTP">HTTP</option>
                </select>
              </div>
            </div>

            {/* 内网目标 */}
            <div>
              <label className="block text-xs font-mono text-slate-300 mb-1">
                内网目标 (IP:Port 或 服务名:Port)
              </label>
              <input
                type="text"
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                placeholder="例如 10.0.0.5:80 或 c1:7002"
                required
                className="w-full px-3 py-2 rounded-lg bg-[#0b101c] border border-[#21324c] text-sm text-slate-100 focus:outline-none focus:border-cyan-500 font-mono"
              />
            </div>

            {/* 负责人 */}
            <div>
              <label className="block text-xs font-mono text-slate-300 mb-1">
                负责人 / 团队
              </label>
              <input
                type="text"
                value={owner}
                onChange={(e) => setOwner(e.target.value)}
                required
                className="w-full px-3 py-2 rounded-lg bg-[#0b101c] border border-[#21324c] text-sm text-slate-100 focus:outline-none focus:border-cyan-500 font-mono"
              />
            </div>

            {/* 备注描述 */}
            <div>
              <label className="block text-xs font-mono text-slate-300 mb-1">
                说明备注
              </label>
              <textarea
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-[#0b101c] border border-[#21324c] text-sm text-slate-100 focus:outline-none focus:border-cyan-500 font-sans"
              />
            </div>
          </form>
        </div>

        {/* Footer actions */}
        <div className="p-6 border-t border-[#1c2a3e] bg-[#121c2e] flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800 text-xs font-mono transition-colors cursor-pointer"
          >
            取消
          </button>
          <button
            type="button"
            disabled={isPortConflict}
            onClick={handleSubmit}
            className="px-5 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-mono text-xs font-semibold shadow-lg shadow-cyan-950/50 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>确认暴露并在拓扑中生效</span>
          </button>
        </div>
      </div>
    </div>
  );
};
