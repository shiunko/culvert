export type ResourceStatus = 'alive' | 'dead' | 'disabled' | 'unknown';
export type ResourceType = 'forward' | 'container' | 'vm' | 'system';
export type ActivityLevel = 'info' | 'warning' | 'error';

export interface ResourceItem {
  id: string;
  name: string;
  ingress: string;
  engine: string;
  target: string;
  type: ResourceType;
  status: ResourceStatus;
  port: number;
  protocol: 'TCP' | 'UDP' | 'HTTP';
  owner: string;
  latency: string;
  throughput: string;
  uptime: string;
  description: string;
  errorMsg?: string;
  updatedAt: string;
}

export interface ActivityEvent {
  id: string;
  timestamp: string;
  title: string;
  operator: string;
  target: string;
  level: ActivityLevel;
  details: string;
  resourceId?: string;
}

export interface PortSegment {
  id: string;
  startPort: number;
  endPort: number;
  label: string;
  service: string;
  owner: string;
  status: ResourceStatus | 'reserved';
  protocol: 'TCP' | 'UDP' | 'HTTP';
  resourceId?: string;
  isReserved?: boolean;
}

export const INITIAL_RESOURCES: ResourceItem[] = [
  {
    id: 'res-1',
    name: 'API 网关主路由',
    ingress: ':8080',
    engine: 'socat',
    target: '10.0.0.5:80',
    type: 'forward',
    status: 'alive',
    port: 8080,
    protocol: 'TCP',
    owner: 'admin',
    latency: '3.8ms',
    throughput: '142 MB/s',
    uptime: '14天 8小时',
    description: '公网流量入口端口映射，代理至核心集群负载均衡器',
    updatedAt: '10秒前'
  },
  {
    id: 'res-2',
    name: '开发控制台前端',
    ingress: 'dev.xxx',
    engine: 'caddy',
    target: 'c1:7002',
    type: 'container',
    status: 'alive',
    port: 7002,
    protocol: 'HTTP',
    owner: 'devops',
    latency: '11.2ms',
    throughput: '58 MB/s',
    uptime: '6天 19小时',
    description: '自动 HTTPS 证书网关，指向开发集群主容器节点 c1',
    updatedAt: '1分钟前'
  },
  {
    id: 'res-3',
    name: '生产主数据库代理',
    ingress: ':3306',
    engine: 'docker:c1',
    target: 'db:3306',
    type: 'container',
    status: 'unknown',
    port: 3306,
    protocol: 'TCP',
    owner: 'dba',
    latency: '82.4ms (延迟偏高)',
    throughput: '315 MB/s',
    uptime: '28天 2小时',
    description: 'MySQL 主库连接隧道，近期连接池线程数逼近上限',
    errorMsg: '主从复制延迟升高，监控指标超出告警阈值',
    updatedAt: '刚刚'
  },
  {
    id: 'res-4',
    name: '微内核虚拟机隔离算力',
    ingress: ':7001',
    engine: 'smolvm:v1',
    target: 'vm:7001',
    type: 'vm',
    status: 'dead',
    port: 7001,
    protocol: 'TCP',
    owner: 'infra',
    latency: 'TIMEOUT',
    throughput: '0 KB/s',
    uptime: '0小时 (离线)',
    description: '轻量隔离微机 SmolVM 执行实例，用于执行临时沙箱代码',
    errorMsg: '心跳超时未响应，目标端口连接被重置 (Connection refused)',
    updatedAt: '2分钟前'
  },
  {
    id: 'res-5',
    name: 'Prometheus 指标采集通道',
    ingress: ':9090',
    engine: 'envoy',
    target: 'k8s:9090',
    type: 'forward',
    status: 'alive',
    port: 9090,
    protocol: 'HTTP',
    owner: 'sre',
    latency: '2.1ms',
    throughput: '18 MB/s',
    uptime: '19天 4小时',
    description: '时序监控指标外拉网关，供远程大屏与运维中台抓取',
    updatedAt: '5分钟前'
  },
  {
    id: 'res-6',
    name: '内部构建缓存与制品代理',
    ingress: ':5000',
    engine: 'nginx',
    target: '10.0.0.22:5000',
    type: 'forward',
    status: 'disabled',
    port: 5000,
    protocol: 'TCP',
    owner: 'ci-bot',
    latency: '-',
    throughput: '0 KB/s',
    uptime: '已停用',
    description: 'Docker Registry 内部拉取缓存，按策略夜间维护休眠',
    errorMsg: '由 CI 规则在构建窗口外禁用',
    updatedAt: '42分钟前'
  },
  {
    id: 'res-7',
    name: 'Redis 缓存分片 01',
    ingress: ':6379',
    engine: 'socat',
    target: '10.0.0.18:6379',
    type: 'forward',
    status: 'alive',
    port: 6379,
    protocol: 'TCP',
    owner: 'backend',
    latency: '0.8ms',
    throughput: '89 MB/s',
    uptime: '31天 11小时',
    description: '高速内存缓存通道，用于会话保持与短连接令牌存储',
    updatedAt: '3分钟前'
  },
  {
    id: 'res-8',
    name: 'Kubernetes Ingress 控制器',
    ingress: ':443/api',
    engine: 'caddy',
    target: 'k8s-ingress:443',
    type: 'container',
    status: 'alive',
    port: 443,
    protocol: 'HTTP',
    owner: 'infra',
    latency: '4.2ms',
    throughput: '420 MB/s',
    uptime: '15天 18小时',
    description: '对外 OpenAPI SSL 终止节点',
    updatedAt: '1分钟前'
  },
  {
    id: 'res-9',
    name: '日志聚合 Elasticsearch',
    ingress: ':9200',
    engine: 'docker:c2',
    target: 'es-cluster:9200',
    type: 'container',
    status: 'alive',
    port: 9200,
    protocol: 'HTTP',
    owner: 'sre',
    latency: '15.6ms',
    throughput: '76 MB/s',
    uptime: '9天 6小时',
    description: '分布式运维日志索引收集入口',
    updatedAt: '12分钟前'
  },
  {
    id: 'res-10',
    name: '边缘计算微机节点 02',
    ingress: ':7002',
    engine: 'smolvm:v2',
    target: 'vm:7002',
    type: 'vm',
    status: 'alive',
    port: 7002,
    protocol: 'TCP',
    owner: 'edge-ops',
    latency: '8.4ms',
    throughput: '12 MB/s',
    uptime: '4天 1小时',
    description: '边缘 AI 推理微容器虚拟机',
    updatedAt: '8分钟前'
  },
  {
    id: 'res-11',
    name: 'Git 私有镜像同步转发',
    ingress: ':2222',
    engine: 'socat',
    target: 'git-server:22',
    type: 'forward',
    status: 'alive',
    port: 2222,
    protocol: 'TCP',
    owner: 'devops',
    latency: '1.5ms',
    throughput: '22 MB/s',
    uptime: '18天 12小时',
    description: 'SSH 协议加密穿透',
    updatedAt: '15分钟前'
  },
  {
    id: 'res-12',
    name: '消息总线 RabbitMQ',
    ingress: ':5672',
    engine: 'socat',
    target: 'mq:5672',
    type: 'forward',
    status: 'alive',
    port: 5672,
    protocol: 'TCP',
    owner: 'backend',
    latency: '1.2ms',
    throughput: '64 MB/s',
    uptime: '22天 7小时',
    description: '核心事件流交换机，吞吐平稳',
    updatedAt: '2分钟前'
  }
];

export const INITIAL_PORT_SEGMENTS: PortSegment[] = [
  {
    id: 'p-80',
    startPort: 80,
    endPort: 80,
    label: ':80 (HTTP 基础网关)',
    service: 'socat → 10.0.0.5:80',
    owner: 'admin',
    status: 'alive',
    protocol: 'TCP',
    resourceId: 'res-1'
  },
  {
    id: 'p-443',
    startPort: 443,
    endPort: 443,
    label: ':443 (HTTPS 入口)',
    service: 'caddy → k8s-ingress',
    owner: 'infra',
    status: 'alive',
    protocol: 'HTTP',
    resourceId: 'res-8'
  },
  {
    id: 'p-2222',
    startPort: 2222,
    endPort: 2222,
    label: ':2222 (SSH Git同步)',
    service: 'socat → git-server:22',
    owner: 'devops',
    status: 'alive',
    protocol: 'TCP',
    resourceId: 'res-11'
  },
  {
    id: 'p-3306',
    startPort: 3306,
    endPort: 3306,
    label: ':3306 (MySQL 代理)',
    service: 'docker:c1 → db:3306',
    owner: 'dba',
    status: 'unknown',
    protocol: 'TCP',
    resourceId: 'res-3'
  },
  {
    id: 'p-5000',
    startPort: 5000,
    endPort: 5000,
    label: ':5000 (构建镜像缓存)',
    service: 'nginx → 10.0.0.22:5000',
    owner: 'ci-bot',
    status: 'disabled',
    protocol: 'TCP',
    resourceId: 'res-6'
  },
  {
    id: 'p-5672',
    startPort: 5672,
    endPort: 5672,
    label: ':5672 (RabbitMQ)',
    service: 'socat → mq:5672',
    owner: 'backend',
    status: 'alive',
    protocol: 'TCP',
    resourceId: 'res-12'
  },
  {
    id: 'p-6379',
    startPort: 6379,
    endPort: 6379,
    label: ':6379 (Redis 缓存)',
    service: 'socat → 10.0.0.18:6379',
    owner: 'backend',
    status: 'alive',
    protocol: 'TCP',
    resourceId: 'res-7'
  },
  {
    id: 'p-7001',
    startPort: 7001,
    endPort: 7001,
    label: ':7001 (SmolVM 沙箱)',
    service: 'smolvm:v1 → vm:7001',
    owner: 'infra',
    status: 'dead',
    protocol: 'TCP',
    resourceId: 'res-4'
  },
  {
    id: 'p-7002',
    startPort: 7002,
    endPort: 7002,
    label: ':7002 (开发控制台)',
    service: 'caddy → c1:7002',
    owner: 'devops',
    status: 'alive',
    protocol: 'HTTP',
    resourceId: 'res-2'
  },
  {
    id: 'p-8080',
    startPort: 8080,
    endPort: 8080,
    label: ':8080 (API 网关)',
    service: 'socat → 10.0.0.5:80',
    owner: 'admin',
    status: 'alive',
    protocol: 'TCP',
    resourceId: 'res-1'
  },
  {
    id: 'p-9090',
    startPort: 9090,
    endPort: 9090,
    label: ':9090 (Prometheus)',
    service: 'envoy → k8s:9090',
    owner: 'sre',
    status: 'alive',
    protocol: 'HTTP',
    resourceId: 'res-5'
  },
  {
    id: 'p-res-system',
    startPort: 10000,
    endPort: 11500,
    label: '10000 - 11500 (平台内核预留段)',
    service: '系统网络栈专用',
    owner: '系统核心',
    status: 'reserved',
    protocol: 'TCP',
    isReserved: true
  },
  {
    id: 'p-res-vpn',
    startPort: 20000,
    endPort: 22000,
    label: '20000 - 22000 (跨节点隧道预留)',
    service: 'WireGuard/VxLAN 内网通道',
    owner: '网络运维',
    status: 'reserved',
    protocol: 'UDP',
    isReserved: true
  },
  {
    id: 'p-res-ephemeral',
    startPort: 49152,
    endPort: 52000,
    label: '49152 - 52000 (临时出站端口段)',
    service: '动态客户端 Socket 分配',
    owner: '内核自动分配',
    status: 'reserved',
    protocol: 'TCP',
    isReserved: true
  }
];

export const INITIAL_ACTIVITIES: ActivityEvent[] = [
  {
    id: 'act-1',
    timestamp: '14:30:12',
    title: '启动转发服务',
    operator: 'admin',
    target: ':8080 → 10.0.0.5:80',
    level: 'info',
    details: '启动 socat TCP 双向端口流，流量路由建立成功',
    resourceId: 'res-1'
  },
  {
    id: 'act-2',
    timestamp: '14:28:45',
    title: '转发异常恢复',
    operator: '系统',
    target: 'dev.xxx → c1:7002',
    level: 'warning',
    details: '执行故障自愈策略，Caddy 重新建立上游 Keep-Alive 管道，补偿操作完成',
    resourceId: 'res-2'
  },
  {
    id: 'act-3',
    timestamp: '14:25:03',
    title: '容器停止',
    operator: 'admin',
    target: 'c1',
    level: 'error',
    details: '节点内存超限触发 cgroups 限制，容器实例被内核终止 (exit 137 OOM)',
    resourceId: 'res-4'
  },
  {
    id: 'act-4',
    timestamp: '14:18:20',
    title: '暴露端口规则生效',
    operator: 'devops',
    target: ':9090 → k8s:9090',
    level: 'info',
    details: 'Envoy ingress route updated, TLS cert verified',
    resourceId: 'res-5'
  },
  {
    id: 'act-5',
    timestamp: '14:10:05',
    title: '数据库复制延迟告警',
    operator: '系统',
    target: 'db:3306',
    level: 'warning',
    details: 'Seconds_Behind_Master 超过 12s，已自动拉起备用读副本流',
    resourceId: 'res-3'
  },
  {
    id: 'act-6',
    timestamp: '13:58:33',
    title: '虚拟机轻量实例启动失败',
    operator: 'infra',
    target: 'smolvm:v1',
    level: 'error',
    details: '微虚机 TAP 设备绑定失败，端口 :7001 无法收发网络帧',
    resourceId: 'res-4'
  },
  {
    id: 'act-7',
    timestamp: '13:45:10',
    title: '安全扫描与策略审计',
    operator: 'security-bot',
    target: '全量端口段 0-65535',
    level: 'info',
    details: '未发现未授权开放端口，预留段策略符合等保三级规范'
  }
];
